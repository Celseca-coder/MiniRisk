import * as echarts from '../../ec-canvas/echarts';
let chart = null;
let chart2 = null;
let comp_id = null;
var categories = [{
  name: "企业"
}, {
  name: "人员"
},{
  name: "事件"
}
];
let options = {
  title: {
    text: '风险知识图谱',
    top: 'bottom',
    left: 'right'
  },
  roam: true,
  tooltip: {},
  legend: [{
    // selectedMode: 'single',
    data: categories.map(function (a) {
      return a.name;
    })
  }],
  animationDuration: 1500,
  animationEasingUpdate: 'quinticInOut',
  series: [{
    name: 'risk graph',
    type: 'graph',
    layout: 'force',
    data: [],
    links: [],
    categories: categories,
    roam: true,
    itemStyle: {
      normal: {
        borderColor: '#fff',
        borderWidth: 1,
        shadowBlur: 10,
        shadowColor: 'rgba(0, 0, 0, 0.3)'
      }
    },
    label: {
      position: '',
      formatter: '{b}'
    },
    lineStyle: {
      color: 'source',
      curveness: 0.3
    },
    emphasis: {
      lineStyle: {
        width: 10
      }
    },
    force: {
      repulsion: 80,
      gravity: 0.01,
      edgeLength: [50, 200]
    }
  }]
};

function initChart(canvas, width, height, dpr) {

  console.log("initchart")

  chart = echarts.init(canvas, null, {
    width: width,
    height: height,
    devicePixelRatio: dpr // 像素
  });
  canvas.setChart(chart);

  console.log("chart",chart)

//   当点击节点时进行跳转到其他企业或产品页面
  chart.on('click', function (params) {
      console.log(
          "click",comp_id,params.data.id
      )
    wx.navigateTo({
      url: '../link/link?source=' + comp_id + '&target=' + params.data.id
    })
  });
  return chart;
}


Page({
  data: {
    ec: {
      onInit: initChart
    },
    // ec2: {
    //   onInit: initChart2
    // },
    loading: true,
    show: false,
    type: 1,
    entity_id: 1,
    comp: {},
    hiddenn: false,
  },

//   onResize(res) {
//     //ec2.resize({ width: '1200px', height: '375px'});
//     // this.setData({
//     //   loading2: false,
//     // })
//     console.log(res.size.windowWidth) // 新的显示区域宽度
//     console.log(res.size.windowHeight) // 新的显示区域高度
//     var temp = this.data.hiddenn;
//     this.setData({
//       hiddenn: temp ? false : true
//     });

//   },

  onChange(event) {
    this.setData({
      activeNames: event.detail
    });
  },

  onChangeBasic(event) {
    this.setData({
      activeBasic: event.detail
    });
  },

  onTab(event) {

  },



  onLoad: function (option) {
    var _this = this;

    // _this.setData({
    //   entity_id: option.id,
    //   type: option.type,
    // })

    console.log("输出这里",option.id)

    option.id=43
    comp_id=option.id

    console.log('option', option)
    //获取企业信息

    wx.request({
      url: 'http://localhost:5000/api/risk/getEntityData/?id=' + option.id,
      header: {
        'content-type': 'application/json' // 默认值
      },
      success(res) {
        _this.setData({
          comp: res.data.comp,
        })
        console.log("comp===",res.data.comp)
      }
    });
    setTimeout(function () {
      _this.getRiskData(option.id);
    }, 1000);
  },
  getRiskData(id) {
    var _this = this;
    wx.request({
      url: 'http://localhost:5000/api/risk/getBlockAge/?companyId=' + id,
      header: {
        'content-type': 'application/json' // 默认值
      },
      success(res) {
        console.log("getRiskData的res",res);
        const graph = res.data;
        options.series[0].data = graph.nodes;
        options.series[0].links = graph.links;
        setTimeout(function () {
          chart.setOption(options);
          // chart2.setOption(options);
        //   _this.save();
        }), 5000;
      }
    });
  },
//   save() {
//     var _this = this;
//     const ecComponent = this.selectComponent('#mychart-dom-bar');
//     // 先保存图片到临时的本地文件，然后存入系统相册
//     ecComponent.canvasToTempFilePath({
//       success: res => {

//         wx.uploadFile({
//           url: 'http://localhost:5000/api/risk/uploadImage',
//           filePath: res.tempFilePath,
//           name: 'file',
//           formData: {
//             'id': _this.data.entity_id
//           },
//           success(res) {
//             const data = res.data
//             //do something
//           }
//         })
//         //存入系统相册
//         wx.saveImageToPhotosAlbum({
//           filePath: res.tempFilePath || '',
//           success: res => {
//             console.log("success", res)
//           },
//           fail: res => {
//             console.log("fail", res)
//           }
//         })
//       },
//       fail: res => console.log(res)
//     });
//   },

});