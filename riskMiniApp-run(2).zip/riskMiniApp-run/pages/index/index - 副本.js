//施策对象不是企业  是事件
//  中物联的施策   库存安全等  施策手段 公式


//每选一个政策出一个图谱，组合政策。精准施策的评估方法。
//评估方法  
// 

//index.js
//获取应用实例




//1.学习历史数据 下拉框 成功案例12345 历史施策 失败的案例12345 。参考
//2 . 施策 每选一个出现一个联动的效果 选两个效果  单个-多个-联动   主动选择  正面效果 负面效果 决策支持  名字改 敏感词  金融施策  政府施策  国家政策
//3  政策  从企业数据  深度学习    基于案例推理




const app = getApp()
var that = this;
const citys = {
  '棉纺织品': ['国际', '国内', '产业链'],
  '钢铁': ['国际', '国内', '产业链'],
  '稀土': ['国际', '国内', '产业链'],
  '牛奶': ['国际', '国内', '产业链'],
  '大米': ['国际', '国内', '产业链'],
  '大豆': ['国际', '国内', '产业链'],
  '蔗糖': ['国际', '国内', '产业链'],
  '其他': ['国际', '国内', '产业链'],
};


const citys2 = {
    '国办': ['政策1', '政策2', '政策3'],
    '中物联': ['政策1', '政策2', '政策3'],
    '央行': ['政策1', '政策2', '政策3'],
  };



const subItems = [
  '稀土金属矿',
  '钍矿砂及其精矿',
  '混合碳酸稀土',
]
import * as echarts from '../../ec-canvas/echarts';
import Toast from '@vant/weapp/toast/toast';
let chart = null

function initChart(canvas, width, height, dpr) {
  chart = echarts.init(canvas, null, {
    width: 350,
    height: 300,
    devicePixelRatio: dpr // 像素
  });
  canvas.setChart(chart);
  var option = {
    title: {
      text: '历史指数',
      left: 'center'
    },
    series: [{
      data: [820, 932, 901, 934, 1290, 1330, 1320],
      type: "line"
    }],
    xAxis: {
      type: 'category',
      data: ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"]
    },
    yAxis: {}
  }
  chart.setOption(option)
  return chart;
}

var year = 2021;
var month = 7;

Page({
  data: {
    isLoaded: false,
    isDisplosed: false,
    ec: {
      lazyLoad: true
    },

    risk: 60,
    loading: true,
    loads: true,
    blockDesc: [],
    desc: [],
    show: false,
    tableShow: false,
    columns: [{
        values: Object.keys(citys),
        className: 'column1',
        disabled: true
      },
      {
        values: citys['牛奶'],
        className: 'column2',
        defaultIndex: 0
      },
      {
        values: ['一月', '二月','三月','四月','五月','六月','七月','八月','九月'],
        className: 'column3',
        defaultIndex: 1
      }
    ],

    columns2: [{
        values: Object.keys(citys2),
        className: 'column1',
        disabled: true
      },
      {
        values: citys2['国办'],
        className: 'column2',
        defaultIndex: 0
      },
      {
        values: ['供应链A', '供应链B', '供应链C'],
        className: 'column3',
        defaultIndex: 1
      }
    ],






    companys: [],
    projects: [],
    consensuses: [],
    activeNames: ['0'],
    analysisResultActiveNames: ['0'],
    credit: [],
    basic: [],
    activeBasic: ['1', '2'],
    active: 0,
    activeEntityType: 0,
    comp: {},
    safetyIndex: [],

    preTab0Value1: '',
    tab0Value1: '钢铁',
    tab0Value2: '国内',
    tab0Value3: '二月',

    tab0Value4: '国办',
    tab0Value5: '政策A',
    tab0Value6: '供应链A',



    blockEntities: [

    ],
    blockEntities2: [

    ],
    blockEntities2Value: 1,
    blockEntity: {},
    riskReport:[],
    carryEntity: {},
    relatedBlockEntities: [

    ],
    blockEntityUserRemarks: [],
    carryEntityUserRemarks: [],
    effect_nums: 0,
    relatedCarryEntities: [],
    carryEntities: [

    ],
    reply: false,
    customize: '',
    tab2CarryEntities: [],
    tab2CarryEntitiesValue: 0,

    customizeCarryEntityId: [],
    customizeCarryEntity1: '',
    customizeCarryEntity2Array: [], //默认显示0个
    customizeCarryEntity2InputVal: [], //所有input的内容

    policyReply: false,
    tab2Policy: [],
    tab2PolicyValue: 0,
    tab2Policy2: [],
    tab2PolicyValue2: 0,
    tab2Policy3: [],
    tab2PolicyValue3: 0,
    customizePolicy1: '',
    customizePolicy2Array: [], //默认显示0个
    customizePolicy2InputVal: [], //所有input的内容

    methodReply: false,
    tab2Method: [],
    tab2MethodValue: 0,
    tab2Method2: [],
    tab2MethodValue2: 0,
    tab2Method3: [],
    tab2MethodValue3: 0,
    customizeMethod1: '',
    customizeMethod2Array: [], //默认显示0个
    customizeMethod2InputVal: [], //所有input的内容

    // 施策分析下载按钮是否禁用，初始禁用
    downLoadAnalysisFileStatus: true,
    // 月度数据报告下载按钮是否禁用，初始禁用
    downLoadAnalysisReoprtStatus:true,
    
    // 风险预警
    riskWarning: '高风险',
    subItemVisible: false,
    subItemColumns: [{
      values: subItems,
      className: 'column1',
    }],
    chosenSupplyItem: '稀土金属矿',
    risk_level: '低风险',
    // 是否显示风险预警和生产安全度提示
    riskVisible: false,

    // 是否显示弹出层
    formulaPopupVisible: false,

    // 以下与popup中的数据来源有关
    supplyQuantity: [],
    activeCollapse: [],
    consumeQuantity: [],
    stockQuantity: [],
    priceQuantity: [],
    priceQuantity: [],
    supplyVisible: false,
    consumeVisible: false,

    chosenIndexTitle: '',

    historyIndex: {},
    isLoaded: false,

    // 指数解读相关
    msgVisible: false,
    msg: [],
    yearOption: [
      { text: '请选择年份', value: 0 },
      { text: '2021年', value: 2021 },
    ],
    monthOption: [
      { text: '请选择月份', value: 0 },
      { text: '一月', value: 1 },
      { text: '二月', value: 2 },
      { text: '三月', value: 3 },
      { text: '四月', value: 4 },
      { text: '五月', value: 5 },
      { text: '六月', value: 6 },
      { text: '七月', value: 7 },
    ],
    year: 2021,
    month: 7,
    buttonDisabled:true,
  },
  jumpToWeb() {
    wx.navigateTo({
      url:'../out/out', 
    })
    console.log('这里用来跳转到外网')
  },
  jumpToTab1() {
    this.setData({
      formulaPopupVisible: false,
      active: 1,
    })
  },
  jumpToTab2() {
    this.setData({
      formulaPopupVisible: false,
      active: 2,
    })
  },
  showPopup() {
    this.setData({
      show: true,
    });
  },
  setOption(chart) {
    const option = {
      title: {
        text: '指数历史数据',
        left: 'center',
      },
      tooltip: {
          trigger: 'axis'
      },
      color: ['#37a2da', '#32c5e9', '#67e0e3'],
      grid: {
        left: 20,
        right: 20,
        bottom: 15,
        top: 40,
        containLabel: true
      },
      xAxis: [
        {
          type: 'category',
          axisLine: {
            lineStyle: {
              color: '#999'
            }
          },
          axisLabel: {
            color: '#666'
          },
          data: this.data['historyIndex']['xAxis']
        }
      ],
      yAxis: {},
      series: [{
        data: this.data['historyIndex']['data'],
        type: 'line'
      }]
    };
    chart.setOption(option);
  },
  updateHistoryIndex() {
    var _this = this;
    this.data.preTab0Value1 = this.data.tab0Value1
    wx.request({
      url: 'http://localhost:5000/api/risk/index/history',
      data: {
        chain: _this.data.tab0Value1,
      },
      success(res) {
        _this.setData({
          historyIndex: res.data,
          isLoaded: true
        })
        setTimeout(() => {
          _this.ecComponent = _this.selectComponent("#history_line")
          _this.ecComponent.init((canvas, width, height, dpr) => {
            // 获取组件的 canvas、width、height 后的回调函数
            // 在这里初始化图表
            const chart = echarts.init(canvas, null, {
              width: width,
              height: height,
              devicePixelRatio: dpr // new
            });
            _this.setOption(chart);
            // // 将图表实例绑定到 this 上，可以在其他成员函数（如 dispose）中访问
            // this.chart = chart;

            // 注意这里一定要返回 chart 实例，否则会影响事件处理等
            return chart;
          })
        }, 1000) 
      }
    })
  },
  loadHistoryIndex(event) {
    // console.log('event', event)
    var _this = this;

    if(event['detail']['title'] === '历史数据') {
      if(this.data.preTab0Value1 !== this.data.tab0Value1) {
        _this.updateHistoryIndex()
      } 
    }
    // wx.request({
    //   url: 'http://localhost:5000/api/risk/index/history',
    //   // data: {
    //   //   type: '',
    //   //   chain: '',
    //   // },
    //   success(res) {
    //     console.log('history index', res)
    //   }

    // });
  },
  // onReady: function() {
  //   this.data.ecComponent = this.selectComponent("#history_line")
  // },
  onClose() {
    this.setData({
      show: false
    });
  },
  onPickerChange(event) {
    const {
      picker,
      value,
      index
    } = event.detail;
    if (index == 0) {
      picker.setColumnValues(1, citys[value[0]]);
      picker.setColumnIndex(1, 0);
    }
    this.setData({
      tableShow: true
    })
  },

  onPickerChange2(event) {
    const {
      picker,
      value,
      index
    } = event.detail;
    if (index == 0) {
      picker.setColumnValues(1, citys2[value[0]]);
      picker.setColumnIndex(1, 0);
    }
    this.setData({
      tableShow: true
    })
  },




  moveHandle() {

  },
  // 供应链选择
  onConfirm(event) {
    var _this = this;
    const {
      picker,
      value,
      index
    } = event.detail;

    _this.setData({
      tab0Value1: value[0],
      tab0Value2: value[1],
      tab0Value3: value[2],
      show: false,
      tableShow: true
    });
    _this.getRiskValue();
    _this.getBlockEntities();
    _this.getCarryEntities();

    //获取tab2所有堵点
    _this.getAllBlockEntities();
    _this.getBlockEntityDetail();
    _this.getBlockage();

    //获取tab3所有疏点
    _this.getAllCarryEntities();
    // 获取决策数据源
    _this.getCalBasic()

    // 获取建议施策
    _this.getBlockInterpretation();
  },

  // 施策选择
  onConfirm2(event) {
    var _this = this;
    const {
      picker,
      value,
      index
    } = event.detail;

    _this.setData({
      tab0Value4: value[0],
      tab0Value5: value[1],
      tab0Value6: value[2],
      show: false,
      tableShow: true
    });
   
  },






  getBlockInterpretation() {
    var _this = this
    wx.request({
      url: 'http://localhost:5000/api/risk/block/interpretation',
      data: {
        chain: _this.data.tab0Value1,
        type: _this.data.tab0Value2,
        month: _this.data.tab0Value3
      },
      success(res) {
        console.log('获取解读', res['data'])
        let policy = res['data']['policy']
        let k = []
        let ka = Object.keys(policy)
        for(let i=0;i<ka.length;++i) {
          k.push({'category': ka[i], 'specific': policy[ka[i]]})
        }
        _this.setData({
          msg: k,
          msgVisible: res['data']['msgIncluded']
        })
      }
    })
  },

  onCancel() {
    this.setData({
      show: false
    })
  },
  // onSwitch1Change({
  //   detail
  // }) {
  //   this.setData({
  //     value1: detail
  //   });
  //   this.getRiskValue();
  //   this.getBlockEntities();
  //   this.getCarryEntities();
  // },

  // onSwitch2Change({
  //   detail
  // }) {
  //   this.setData({
  //     value2: detail
  //   });
  //   this.getRiskValue();
  //   this.getBlockEntities();
  //   this.getCarryEntities();
  // },

  onSwitch3Change({
    detail
  }) {
    var _this = this;
    _this.setData({
      blockEntities2Value: detail,
      blockEntityUserRemarks: []
    });
    _this.getBlockEntityDetail();
    _this.getBlockage();
    _this.getUserRemarks(app.globalData.openid, _this.data.blockEntities2Value, 1);

  },


  toVisible() {
      console.log("可视化堵点分析",this.data.blockEntities2Value)
    wx.navigateTo({
      url: '../graph/graph?id=' + this.data.blockEntities2Value + '&type=0'
    })
    // this.setData({
    //   loading: !this.data.loading,
    // })
    // console.log("loading: "+ this.data.loading);

    // console.log(options.series[0].data );
    // console.log(options.series[0].links )
  },

  analysisVisualization() {
    console.log("疏导结果",this.data.tab2CarryEntitiesValue)
    wx.navigateTo({
      url: '../graph/graph?id=' + this.data.tab2CarryEntitiesValue + '&type=0'
    })
    // this.setData({
    //   loading: !this.data.loading,
    // })
    // console.log("loading: "+ this.data.loading);

    // console.log(options.series[0].data );
    // console.log(options.series[0].links )
  },
  onChange(event) {
    this.setData({
      activeNames: event.detail
    });
  },

  onChangeBasic(event) {
    this.setData({
      activeBasic: event.detail
    });
  },
  analysisResultOnChange(event) {

    this.setData({
      analysisResultActiveNames: event.detail
    });
  },
  onTab(event) {
    var _this = this;

  },
  onTab1(event) {

    this.setData({
      activeEntityType: event.detail.index,
    })

  },
  blockEntityBind(event) {
    console.log(event)
    wx.navigateTo({
      url: '../graph/graph?id=' + event.currentTarget.dataset.id + '&type=0'
    })
  },
  carryEntityBind(event) {

    wx.navigateTo({
      url: '../graph/graph?id=' + event.currentTarget.dataset.id + '&type=1'
    })
  },
  onLoad: function (option) {
    Toast.loading({
      mask: true,
      message: '加载中...',
      duration: 2500
    });
    var _this = this;
    _this.getRiskValue();
    _this.getBlockEntities();
    _this.getCarryEntities();
    _this.getTab2Ready();
    _this.getTab3Ready();
    _this.getCalBasic();
    _this.getBlockInterpretation();
    _this.getRecords();
  },

  //获取风险值
  getRiskValue() {
    var _this = this;
    var risk_name = _this.data.tab0Value1;
    var risk_type = _this.data.tab0Value2;
    wx.request({
      url: 'http://localhost:5000/api/risk/getRiskValue/?risk_name=' + risk_name + '&risk_type=' + risk_type,
      header: {
        'content-type': 'application/json' // 默认值
      },
      success(res) {
        console.log('供应', res)
        let rv = false
        let arr = [
          {
            title: '库存安全度',
            value: res.data.repertory_risk_value
          },
          {
            title: '价格安全度',
            value: res.data.fund_risk_value
          },
          {
            title: '物流安全度',
            value: res.data.logistics_risk_value
          },
          {
            title: '商贸安全度',
            value: res.data.commerce_risk_value
          },

        ]
        if('security_index' in res.data) {
          rv = true
          arr.splice(0, 0, {title: '供应安全指数', value:res.data.security_index})
        }
        _this.setData({
          risk: res.data.risk_value,
          safetyIndex: arr,
          risk_level:  'risk_level' in res.data ? res.data.risk_level : '',
          riskVisible: rv
          // supplySafetyIndex: 'supply_safety_index' in res.data ? res.data.supply_safety_index : 0,
          // riskWarning: 'risk_warning' in res.data ? res.data.risk_warning : '',
        })
      }
    })
  },
  //初始化tab2堵点分析
  getTab2Ready() {
    var _this = this;
    _this.getAllBlockEntities();
    _this.getBlockEntityDetail();
    _this.getBlockage();


  },
  //初始化tab3施策及疏点分析
  getTab3Ready() {
    var _this = this;
    _this.getAllCarryEntities();
    _this.getPolicies();
    // _this.getMethods();

    _this.getPolicies2();


    _this.getPolicies3();



  },
  //初始化政策工具箱数据
  getPolicies() {

    // var _this = this;
    // wx.request({
    //   url: 'http://localhost:5000/api/risk/getPolicies/',
    //   header: {
    //     'content-type': 'application/json' // 默认值
    //   },
    //   success(res) {

    //     var tempArry = [];
    //     // for (var i = 0; i < res.data.policies.length; i++) {
    //     //   var tempIndex = {
    //     //     text: '1',
    //     //     value: 1
    //     //   }
    //     //   var te = res.data.policies[i][1];
    //     //   var val = res.data.policies[i][0];
    //     //   console.log("te val",te,val)
    //     //   tempIndex.text = te;
    //     //   tempIndex.value = val;
    //     //   tempArry.push(tempIndex);
    //     // }
    //     tempArry.push(
    //       {
    //         text: "国办施策手段",
    //         value: 0
    //       }
          
    //     );
        


    //     _this.setData({
    //       tab2Policy: tempArry,
    //       tab2PolicyValue: tempArry[0].value
    //     })

    //   }

    // });

    var tempArry = [];
 
    tempArry.push(
        {
          text: "国办施策手段",
          value: 0
        }
    );
    
    this.setData({
    tab2Policy: tempArry,
    tab2PolicyValue: tempArry[0].value
    })


    var tempArry2 = []
        tempArry2.push({
            text: "国办政策A",
        value: 0
        })
        tempArry2.push({
                text: "国办政策B",
            value: 1
        })
        tempArry2.push({
            text: "国办政策C",
        value: 2
        })
        this.setData({
                  tab2Method: tempArry2,
                  tab2MethodValue: tempArry2[0].value
        })
},

getPolicies2() {

    var tempArry = [];
 
    tempArry.push(
        {
          text: "发改委施策手段",
          value: 0
        }
    );
    
    this.setData({
    tab2Policy2: tempArry,
    tab2PolicyValue2: tempArry[0].value
    })


    var tempArry2 = []
        tempArry2.push({
            text: "发改委市场政策",
        value: 0
        })
        tempArry2.push({
                text: "发改委金融政策",
            value: 1
        })
        tempArry2.push({
            text: "发改委其它政策",
        value: 2
        })
        this.setData({
                  tab2Method2: tempArry2,
                  tab2MethodValue2: tempArry2[0].value
        })
},


getPolicies3() {

    var tempArry = [];
 
    tempArry.push(
        {
          text: "央行施策手段",
          value: 0
        }
    );
    
    this.setData({
    tab2Policy3: tempArry,
    tab2PolicyValue3: tempArry[0].value
    })


    var tempArry2 = []
        tempArry2.push({
            text: "央行市场政策",
        value: 0
        })
        tempArry2.push({
                text: "央行金融政策",
            value: 1
        })
        tempArry2.push({
            text: "央行其它政策",
        value: 2
        })
        this.setData({
                  tab2Method3: tempArry2,
                  tab2MethodValue3: tempArry2[0].value
        })
},


  //初始化疏解方法
//   getMethods() {

//     // console.log("thismethod2",this.data.tab2Method)
    

//     var _this = this;
//     console.log("shujie",_this.data.tab2PolicyValue)


//     var tempArry = [];
//     if(_this.data.tab2PolicyValue==0){
//         tempArry = []
//         tempArry.push({
//             text: "国办政策A",
//         value: 0
//         })
//         tempArry.push({
//                 text: "国办政策B",
//             value: 1
//         })
//         tempArry.push({
//             text: "国办政策C",
//         value: 2
//     })
//     }

//     else if(_this.data.tab2PolicyValue==1){
//         tempArry = []
//         tempArry.push({
//             text: "发改委市场政策",
//         value: 0
//         })
//         tempArry.push({
//                 text: "发改委金融政策",
//             value: 1
//         })
//         tempArry.push({
//             text: "发改委其它政策",
//         value: 2
//     })
//     }

//     else if(_this.data.tab2PolicyValue==2){
//         tempArry = []
//         tempArry.push({
//             text: "央行施策手段-调节利率",
//         value: 0
//         })
//         tempArry.push({
//                 text: "央行施策手段-放宽贷款",
//             value: 1
//         })
//         tempArry.push({
//             text: "央行施策手段-加息",
//         value: 2
//         })
//         tempArry.push({
//             text: "央行施策手段-降息",
//         value: 3
//         })
//     }
//     else if(_this.data.tab2PolicyValue==3){
//         tempArry = []
//         tempArry.push({
//             text: "补贴",
//         value: 0
//         })
//         tempArry.push({
//                 text: "研发",
//             value: 1
//         })
//         tempArry.push({
//             text: "免税",
//         value: 2
//         })
//     }
        

    

//     tempArry.push({
//       text: "其他",
//       value: 3
//     });


    
//     _this.setData({
//       tab2Method: tempArry,
//       tab2MethodValue: tempArry[0].value
//     })

//     console.log("thismethod",_this.data.tab2Method)
    


//     wx.request({
//       url: 'http://localhost:5000/api/risk/getMethodsByPolicy/?id=' + _this.data.tab2PolicyValue,
//       header: {
//         'content-type': 'application/json' // 默认值
//       },
//       success(res) {

//         var tempArry = [];
//         // for (var i = 0; i < res.data.methods.length; i++) {
//         //   var tempIndex = {
//         //     text: '1',
//         //     value: 1
//         //   }
//         //   var te = res.data.methods[i].name;
//         //   var val = res.data.methods[i].id;
//         //   tempIndex.text = te;
//         //   tempIndex.value = val;
//         //   tempArry.push(tempIndex);
//         // }

//         if(_this.data.tab2PolicyValue==0){
//             tempArry = []
//             tempArry.push({
//                 text: "国办政策A",
//             value: 0
//             })
//             tempArry.push({
//                     text: "国办政策B",
//                 value: 1
//             })
//             tempArry.push({
//                 text: "国办政策C",
//             value: 2
//         })
//         }

//         else if(_this.data.tab2PolicyValue==1){
//             tempArry = []
//             tempArry.push({
//                 text: "发改委市场政策",
//             value: 0
//             })
//             tempArry.push({
//                     text: "发改委金融政策",
//                 value: 1
//             })
//             tempArry.push({
//                 text: "发改委其它政策",
//             value: 2
//         })
//         }

//         else if(_this.data.tab2PolicyValue==2){
//             tempArry = []
//             tempArry.push({
//                 text: "央行施策手段-调节利率",
//             value: 0
//             })
//             tempArry.push({
//                     text: "央行施策手段-放宽贷款",
//                 value: 1
//             })
//             tempArry.push({
//                 text: "央行施策手段-加息",
//             value: 2
//             })
//             tempArry.push({
//                 text: "央行施策手段-降息",
//             value: 2
//             })
//         }
            

//         console.log("temp",tempArry)

//         tempArry.push({
//           text: "其他",
//           value: 3
//         });


        
//         _this.setData({
//           tab2Method: tempArry,
//           tab2MethodValue: tempArry[0].value
//         })

//         console.log("thismethod",_this.data.tab2Method)

//       }

//     });
//   },


  //自动匹配政策
  pipei() {
    var _this = this;
    console.log("pipei",_this.data.tab2Policy)
 
    Toast({
        type: 'loading',
        message: '自动匹配政策计算中...请稍后……',
        duration: 2000,
        onClose: () => {
            Toast({
                type: 'success',
                message: '已根据数据和算法为您推荐政策和工具！',
                duration: 3500,
              });  

            var i= Math.round(Math.random()*2)
            var j= Math.round(Math.random()*2)
            var k= Math.round(Math.random()*2)

            console.log("i==",i,"j==",j,k)


            // _this.setData({

            // tab2PolicyValue:i,
            // });
            //获取对应的方法数组    
            // _this.getMethods()  
            _this.setData({
                tab2MethodValue:j,
                tab2MethodValue2:i,
                tab2MethodValue3:k
                });     

            
        }
      });

  },


  //多重政策
  many() {
    var _this = this;
    console.log("many",_this.data.tab2Policy)
 
    // Toast({
    //     type: 'loading',
    //     message: '多重政策分析中...请稍后……',
    //     duration: 2000,
    //     onClose: () => {
            wx.showModal({
                title: '施策分析政策匹配确认',
                content: '您选择的施策对象是,【'+_this.data.tab2CarryEntities[_this.data.tab2CarryEntitiesValue].text +'】，施策工具1是：【国办施策手段】,疏解方法是：【'+_this.data.tab2Method[_this.data.tab2MethodValue].text+'】,施策工具2是：【发改委施策手段】,疏解方法是：【'+_this.data.tab2Method2[_this.data.tab2MethodValue2].text+'】,施策工具3是：【央行施策手段】,疏解方法是：【'+_this.data.tab2Method3[_this.data.tab2MethodValue3].text
                +'】。                        国办的政策直接影响到国务院日常工作，发改委政策会影响多个部门决策，央行施策会影响银行的决策，请仔细考虑',
                success (res) {
                    if (res.confirm) {
                        Toast({
                            type: 'loading',
                            message: '多重政策分析中...请稍后……',
                            duration: 2000,
                            onClose: () => {

                                wx.showModal({
                                    title: '施策的直接效果',
                                    content:'【'+_this.data.tab2Method[_this.data.tab2MethodValue].text+'】使国务院对该事件给出了指导政策，从系统层面解决了一些堵点。【'+_this.data.tab2Method2[_this.data.tab2MethodValue2].text+'】提高了该事件在市场中【'+Math.round(Math.random()*50)+'%】的效率，【'+_this.data.tab2Method3[_this.data.tab2MethodValue3].text+'】会导致【'+Math.round(Math.random()*100)+'】家银行加大对该领域的投资'
                                })

                            }
                        })


                        

                        
                    } 
                    else if (res.cancel) {
                        console.log('用户点击取消')
                    }
                }
            }) 
    
    //     }
    //   });

  },


  //施策分析
  analysis() {
 
    var _this = this;
    console.log("tab2policy",_this.data.tab2Policy)
    wx.showModal({
        title: '施策分析政策匹配确认',
        content: '您选择的施策对象是,【'+_this.data.tab2CarryEntities[_this.data.tab2CarryEntitiesValue].text +'】\r\n，施策工具1是：【国办施策手段】,疏解方法是：【'+_this.data.tab2Method[_this.data.tab2MethodValue].text+'】\r\n,施策工具2是：【发改委施策手段】,疏解方法是：【'+_this.data.tab2Method2[_this.data.tab2MethodValue2].text+'】\r\n,施策工具3是：【央行施策手段】,疏解方法是：【'+_this.data.tab2Method3[_this.data.tab2MethodValue3].text+'】\r\n,该疏解工具和方法将对供应链相关节点造成影响，请确定是否继续？',
        success (res) {
            if (res.confirm) {
                console.log('用户点击确定')
                Toast({
                      type: 'loading',
                      message: '施策分析中...',
                      duration: 1500,
                      onClose: () => {
                        
                        wx.showModal({
                            title: '施策分析结果',
                            content: '该操作对主体节点和相关【【'+Math.round(Math.random()*15)+'】】个节点造成影响,减少的系统风险值为：【【'+Math.round(Math.random()*10)+'】】,点击查看相关节点',
                            success (res) {
                                if (res.confirm) {
                                    console.log('用户点击确定')
                                    _this.toVisible()
  
                                } 
                                else if (res.cancel) {
                                    console.log('用户点击取消')
                                }
                            }
                        })

                      }
                    });
                
                
            } 
            else if (res.cancel) {
                console.log('用户点击取消')
            }
        }
    })
    
    _this.setData({
      carryEntityUserRemarks: []
    })
    // var carryEntityId = _this.data.tab2CarryEntitiesValue;

    // if (carryEntityId == 0) {
    //   _this.setData({
    //     customizeCarryEntityId: []
    //   })

    //   _this.getEntityIdByName(_this.data.customizeCarryEntity1);

    //   for (var i = 0; i < _this.data.customizeCarryEntity2InputVal.length; i++) {
    //     _this.getEntityIdByName(_this.data.customizeCarryEntity2InputVal[i]);
    //   }
    // } else {
    //   _this.getCarryEntityDetail(carryEntityId);
    //   _this.getCarryEffect(carryEntityId);
    //   setTimeout(function () {
    //     _this.getUserRemarks(app.globalData.openid, carryEntityId, 2);
    //   }, 2000);
    //   setTimeout(function () {
    //     Toast.clear();
    //     Toast.success('施策成功...');
    //   }, 2000);
    // }
    // _this.setData({
    //   downLoadAnalysisFileStatus: false
    // });

  },
  downLoadAnalysisFile() {
    var _this = this;
    _this.getShareFileUrl(_this.data.tab0Value1, _this.data.tab0Value2, _this.data.tab2CarryEntitiesValue, _this.data.tab2PolicyValue, _this.data.tab2MethodValue)

  },
  report(event) {
    var _this = this;
    wx.navigateTo({
      url: '../report/report?entityId=' + event.currentTarget.dataset.idx,
      events: {
        // 为指定事件添加一个监听器，获取被打开页面传送到当前页面的数据
        acceptDataFromOpenedPage: function (data) {

          if (event.currentTarget.dataset.type == "1") {
            var temp = _this.data.blockEntityUserRemarks;
            temp.push(data.data)
            _this.setData({
              blockEntityUserRemarks: temp
            })

            console.log("blockEntityUserRemarks" + _this.data.blockEntityUserRemarks)
          } else {
            var temp = _this.data.carryEntityUserRemarks;

            temp.push(data.data)
            _this.setData({
              carryEntityUserRemarks: temp
            })

          }
        }
      }
    })
  },
  getUserRemarks(openid, entityId, type) {
    console.log(type + " getUserRemarks开始执行。。。。")
    console.log(openid + '..' + entityId + '..' + type)
    var _this = this;

    wx.request({
      url: 'http://localhost:5000/api/risk/login/getUserRemarks/?openid=' + openid + '&entityId=' + entityId,
      header: {
        'content-type': 'application/json' // 默认值
      },
      success(res) {
        console.log(res)
        if (type == 1) {
          _this.setData({
            blockEntityUserRemarks: res.data.remarks
          })
          console.log(_this.data.blockEntityUserRemarks);
        } else {
          _this.setData({
            carryEntityUserRemarks: res.data.remarks
          })
          console.log(_this.data.carryEntityUserRemarks);
        }
      }
    });
  },
  getEntityIdByName(name) {
    var _this = this;
    wx.request({
      url: 'http://localhost:5000/api/risk/getEntityByName/?name=' + name,
      header: {
        'content-type': 'application/json' // 默认值
      },
      success(res) {
        if (res.data.entityId == -1 || _this.data.customizeCarryEntityId.indexOf(res.data.entityId) > -1) {
          Toast.clear();
          Toast.fail('输入有误...');
          return;
        } else {
          var temp = _this.data.customizeCarryEntityId;
          temp.push(res.data.entityId);
          _this.setData({
            customizeCarryEntityId: temp
          })
          Toast.clear();
          Toast.success('施策成功...');
        }
      }
    });
  },
  //获取对指定节点的施策效果
  getCarryEffect(entityId) {
    var _this = this;
    wx.request({
      url: 'http://localhost:5000/api/risk/getCarryEffect/?id=' + entityId + '&policy_id=' + 1 + '&method_id=' + 1,
      header: {
        'content-type': 'application/json' // 默认值
      },
      success(res) {

        _this.setData({
          relatedCarryEntities: res.data.nodes,
          effect_nums: res.data.effect_nums
        })
        var desc = [];
        console.log(_this.data.relatedCarryEntities.length);
        desc.push("本次施策共影响主体" + res.data.nodes.length + "个，预计疏通主体" + res.data.effect_nums + "个，疏解效果" + (res.data.nodes.length < res.data.effect_nums * 2 ? "良好" : "一般"));
        _this.setData({
          desc: desc,
          loads: false,
          analysisResultActiveNames: ['1'],
        });
      }
    });
  },
    //生成分析报告
    getShareFileUrl(chainName, chainType, entityId, policyId, methodId) {
      var _this = this;
      var urlData = 'http://localhost:5000/api/risk/makeCarryFile/?chain_name=' + encodeURIComponent(chainName) + '&chain_type=' + encodeURIComponent(chainType) + '&entity_id=' + entityId + '&policy_id=' + 1 + '&method_id=' + 1 ;
          wx.setClipboardData({
            data: urlData + "，点击链接查看施策仿真分析报告【来自供应链安全评估与施策仿真】",
            success(res) {
              wx.getClipboardData({
                success(sres) {
                  console.log(sres.data) // data
                }
              })
            }
          })

    },
  //获取堵点详细信息
  getBlockEntityDetail() {
    var _this = this;
    setTimeout(function () {
      wx.request({
        url: 'http://localhost:5000/api/risk/getEntityData/?id=' + _this.data.blockEntities2Value,
        header: {
          'content-type': 'application/json' // 默认值
        },
        success(res) {
          console.log('成功获取堵点详细信息',res);

          if(res.data.comp[4]>70){
            res.data.comp[1]+="--【风险企业】"
          }


        //   res.data.comp[1]="暴雷企业恒大"
          _this.setData({
            blockEntity: res.data.comp,
          })
        }

      });
    }, 2000);
  },
  getCarryEntityDetail(id) {

    var _this = this;
    wx.request({
      url: 'http://localhost:5000/api/risk/getEntityData/?id=' + id,
      header: {
        'content-type': 'application/json' // 默认值
      },
      success(res) {
        console.log(res.data.comp)
        _this.setData({
          carryEntity: res.data.comp,
        })
      }

    });
  },
  //获取堵点关联信息
  getBlockage() {
    var _this = this;
    setTimeout(function () {
      wx.request({
        url: 'http://localhost:5000/api/risk/getBlockAge/?companyId=' + _this.data.blockEntities2Value,
        header: {
          'content-type': 'application/json' // 默认值
        },
        success(res) {
            console.log("成功获取到堵点关联信息",res.data.nodes)
          res.data.nodes.forEach((value, index) => {
            if(value.name === '新冠疫情') {
              res.data.nodes.splice(index, 1)
            }
          })

          _this.setData({
            relatedBlockEntities: res.data.nodes,
          })
          
          var desc = [];
          desc.push(_this.data.blockEntity[1] + "堵塞，预计共" + _this.data.relatedBlockEntities.length + "个主体会受到影响，造成影响" + (_this.data.relatedBlockEntities.length > 5 ? "严重" : "一般"));
          _this.setData({
            blockDesc: desc,
          });
          // const graph = res.data;
          // options.series[0].data = graph.nodes;
          // options.series[0].links = graph.links;
          // chart.setOption(options);
          // console.log("chart option设置成功。。")
        }
      });
    }, 2100);
  },
  
  // tab1  获取对应供应链的堵点
  getBlockEntities() {
    var _this = this;
    var risk_name = _this.data.tab0Value1;
    var risk_type = _this.data.tab0Value2;
    console.log("here1",risk_name,risk_type)
    wx.request({
      url: 'http://localhost:5000/api/risk/getBlockEntities/?category=' + risk_name + '&risk_type=' + risk_type,
      header: {
        'content-type': 'application/json' // 默认值
      },
      success(res) {
        console.log("成功获取到堵点",res.data.entities)
        for(var i=0;i<res.data.entities.length;i++){
            if(res.data.entities[i][2]>70)
            res.data.entities[i][1]+="---【风险企业】"
        }
        
        
        _this.setData({
          blockEntities: res.data.entities,
        })
      }

    })

  },
  // tab2 获取对应供应链的所有堵点
  getAllBlockEntities() {
    console.log("获取tab2所有堵点.......")
    var _this = this;
    var risk_name = _this.data.tab0Value1;
    var risk_type = "";
    console.log("here",risk_name,risk_type)
    wx.request({
      url: 'http://localhost:5000/api/risk/getBlockEntities/?category=' + risk_name + '&risk_type=' + risk_type,
      header: {
        'content-type': 'application/json' // 默认值
      },
      success(res) {
        var tempArry = [];
        for (var i = 0; i < res.data.entities.length; i++) {
          var tempIndex = {
            text: '1',
            value: 1
          }
          var te = res.data.entities[i][1];
          var val = res.data.entities[i][0];
          tempIndex.text = te;
          tempIndex.value = val;
          tempArry.push(tempIndex);
        }
        console.log("成功获取到所有堵点",tempArry)

        // for (var i = 0; i < tempArry.length; i++) {
        //     if(tempArry[i]){
        //         tempArry[0].text="暴雷企业"
        //     }

        // }

        
        _this.setData({
          blockEntities2: tempArry,
          blockEntities2Value: tempArry[0].value   //序号
        })
        setTimeout(function () {
          _this.getUserRemarks(app.globalData.openid, _this.data.blockEntities2Value, 1);
        }, 1000);
      }
    })
  },
  //获取对应供应链的疏点
  getCarryEntities() {
    var _this = this;
    var risk_name = _this.data.tab0Value1;
    var risk_type = _this.data.tab0Value2;
    wx.request({
      url: 'http://localhost:5000/api/risk/getCarryEntities/?category=' + risk_name + '&risk_type=' + risk_type,
      header: {
        'content-type': 'application/json' // 默认值
      },
      success(res) {
        _this.setData({
          carryEntities: res.data.entities,
        });
        console.log('疏点', res.data.entities, res)
      }
    })
  },
  //获取供应链所有建议疏点
  getAllCarryEntities() {
    var _this = this;
    var risk_name = _this.data.tab0Value1;
    var risk_type = "";
    wx.request({
      url: 'http://localhost:5000/api/risk/getCarryEntities/?category=' + risk_name + '&risk_type=' + risk_type,
      header: {
        'content-type': 'application/json' // 默认值
      },
      success(res) {
        var tempArry = [];
        // for (var i = 0; i < res.data.entities.length; i++) {
        //   var tempIndex = {
        //     text: '1',
        //     value: 1
        //   }
        //   var te = res.data.entities[i][1];
        //   var val = res.data.entities[i][0];
        //   tempIndex.text = te;
        //   tempIndex.value = val;
        //   tempArry.push(tempIndex);
        // }
        tempArry.push({
            text: "恒大暴雷事件",
            value: 0
          });
          tempArry.push({
            text: "雪松暴雷事件",
            value: 1
          });
          tempArry.push({
            text: "芯片供应链事件",
            value: 2
          });
        tempArry.push({
          text: "其他",
          value: 3
        });
        _this.setData({
          tab2CarryEntities: tempArry,
          tab2CarryEntitiesValue: tempArry[0].value,
        })
      }
    })
  },
  navigateToMiniProgram(event){
    // console.log(event.currentTarget.dataset.idx)
    wx.navigateToMiniProgram({
      appId: 'wx5a7e18cbda07907e',
      path: 'pages/graph/graph?flag=2&graph='+ event.currentTarget.dataset.idx,
      extraData: {
        from: '供应链安全管理'
      },
      envVersion: 'release',
      success(res) {
        // 打开其他小程序成功同步触发
        wx.showToast({
          title: '跳转成功'
        })
      }
    })
  },
  tab2CarryEntitiesBind({
    detail
  }) {
      console.log("tab2bindentiti",detail)
    var _this = this;
    _this.setData({
      tab2CarryEntitiesValue: detail,

    });
    if (detail == 0) {
    //   _this.setData({
    //     reply: true,
    //   });
    } else {
      _this.setData({
        reply: false,
        customizeCarryEntity2Array: [], //默认显示一个
        customizeCarryEntity2InputVal: [] //所有input的内容
      })
    }
  },
  customizeCarryEntity(event) {
    var _this = this;

    _this.setData({
      customizeCarryEntity1: event.detail,
    })
  },
  //获取input的值
  getInputVal: function (e) {

    var nowIdx = e.currentTarget.dataset.idx; //获取当前索引
    var val = e.detail; //获取输入的值
    var oldVal = this.data.customizeCarryEntity2InputVal;
    oldVal[nowIdx] = val; //修改对应索引值的内容
    this.setData({
      customizeCarryEntity2InputVal: oldVal
    });

  },
  //添加input
  addInput: function () {
    var old = this.data.customizeCarryEntity2Array;
    old.push(1); //这里不管push什么，只要数组长度增加1就行
    this.setData({
      customizeCarryEntity2Array: old
    })
  },
  //删除input
  delInput: function (e) {
    var nowidx = e.currentTarget.dataset.idx; //当前索引
    var oldInputVal = this.data.customizeCarryEntity2InputVal; //所有的input值
    var oldarr = this.data.customizeCarryEntity2Array; //循环内容
    oldarr.splice(nowidx, 1); //删除当前索引的内容，这样就能删除view了
    oldInputVal.splice(nowidx, 1); //view删除了对应的input值也要删掉

    this.setData({
      customizeCarryEntity2Array: oldarr,
      customizeCarryEntity2InputVal: oldInputVal
    })
  },
//   tab2PolicyBind({
//     detail
//   }) {
//     var _this = this;

//     _this.setData({
//       tab2PolicyValue: detail,
//     });
//     if (detail == 0) {
//     //   _this.setData({
//     //     policyReply: true,
//     //   });
//     } else {
//       _this.getMethods();
//       _this.setData({
//         policyReply: false,
//         customizePolicy2Array: [], //默认显示0个
//         customizePolicy2InputVal: [], //所有input的内容
//       })
//     }

//   },
  customizePolicy(event) {
    var _this = this;

    _this.setData({
      customizePolicy1: event.detail,
    })
  },
  //获取input的值
  getPolicyInputVal: function (e) {

    var nowIdx = e.currentTarget.dataset.idx; //获取当前索引
    var val = e.detail; //获取输入的值

    console.log("policy",e.detail)

    var oldVal = this.data.customizePolicy2InputVal;
    oldVal[nowIdx] = val; //修改对应索引值的内容
    this.setData({
      customizePolicy2InputVal: oldVal
    });

  },
  //添加input
  addPolicyInput: function () {
    var old = this.data.customizePolicy2Array;
    old.push(1); //这里不管push什么，只要数组长度增加1就行
    console.log('old', old)
    this.setData({
      customizePolicy2Array: old
    })
  },
  //删除input
  delPolicyInput: function (e) {
    var nowidx = e.currentTarget.dataset.idx; //当前索引
    var oldInputVal = this.data.customizePolicy2InputVal; //所有的input值
    var oldarr = this.data.customizePolicy2Array; //循环内容
    oldarr.splice(nowidx, 1); //删除当前索引的内容，这样就能删除view了
    oldInputVal.splice(nowidx, 1); //view删除了对应的input值也要删掉

    this.setData({
      customizePolicy2Array: oldarr,
      customizePolicy2InputVal: oldInputVal
    })
  },

  tab2MethodBind({
    detail
  }) {

    this.setData({
      tab2MethodValue: detail,
    });
    // if (detail == 0) {
    // //   this.setData({
    // //     methodReply: true,
    // //   });
    // } else {
    //   this.setData({
    //     methodReply: false,
    //     customizeMethod2Array: [], //默认显示0个
    //     customizeMethod2InputVal: [], //所有input的内容
    //   })
    // }
  },

  tab2MethodBind2({
    detail
  }) {

    this.setData({
      tab2MethodValue2: detail,
    });
},

tab2MethodBind3({
    detail
  }) {

    this.setData({
      tab2MethodValue3: detail,
    });
},

  customizeMethod(event) {
    var _this = this;

    _this.setData({
      customizeMethod1: event.detail,
    })
  },
  //获取input的值
  getMethodInputVal: function (e) {

    var nowIdx = e.currentTarget.dataset.idx; //获取当前索引
    var val = e.detail; //获取输入的值
    var oldVal = this.data.customizeMethod2InputVal;
    oldVal[nowIdx] = val; //修改对应索引值的内容
    this.setData({
      customizeMethod2InputVal: oldVal
    });

  },
  //添加input
  addMethodInput: function () {
    var old = this.data.customizeMethod2Array;
    old.push(1); //这里不管push什么，只要数组长度增加1就行
    this.setData({
      customizeMethod2Array: old
    })
  },
  //删除input
  delMethodInput: function (e) {
    var nowidx = e.currentTarget.dataset.idx; //当前索引
    var oldInputVal = this.data.customizeMethod2InputVal; //所有的input值
    var oldarr = this.data.customizeMethod2Array; //循环内容
    oldarr.splice(nowidx, 1); //删除当前索引的内容，这样就能删除view了
    oldInputVal.splice(nowidx, 1); //view删除了对应的input值也要删掉

    this.setData({
      customizeMethod2Array: oldarr,
      customizeMethod2InputVal: oldInputVal
    })
  },
  showSubItem() {
    this.setData({
      subItemVisible: true,
    });
  },
  onSubItemClose() {
    this.setData({
      subItemVisible: false,
    });
  },
  onItemPickerChange(event) {
    const {
      picker,
      value,
      index
    } = event.detail;
    if (index == 0) {
      picker.setColumnValues(1, citys[value[0]]);
      picker.setColumnIndex(1, 0);
    }
  },
  // 供应链选择
  onItemConfirm(event) {
    var _this = this;
    const {
      picker,
      value,
      index
    } = event.detail;
    console.log(event)
    
    _this.setData({
      chosenSupplyItem: value[0],
      subItemVisible: false
    })
  },

  // 弹出展示公式、计算方法和历史数据的弹出框
  showFormula(e) {
    var _this = this;
    console.log(e)
    // if(e.target.id === '供应安全指数') {
      _this.setData({
        formulaPopupVisible: true,
        chosenIndexTitle: e.target.id
      })
    // }
  },
  closeFormula() {
    this.setData({
      formulaPopupVisible: false
    })
  },
  getCalBasic() {
    var _this = this;
    var risk_name = _this.data.tab0Value1;
    wx.request({
      url: 'http://localhost:5000/api/risk/HistoryInfo',
      data: {
        type: risk_name
      },
      header: {
        'contenty-type': 'application/json'
      },
      success(res) {
        console.log('new controlelr', res)
        _this.setData({
          supplyQuantity: res.data.supplyQuantity,
          consumeQuantity: res.data.consumeQuantity,
          supplyVisible: res.data.supplyQuantity.length > 0,
          consumeVisible: res.data.consumeQuantity.length > 0,
          stockQuantity: res.data.stockQuantity,
          priceQuantity: res.data.priceQuantity
        })
      }
    })
  },
  onChangeCollapse(event) {
    var _this = this
    _this.setData({
      activeCollapse: event.detail
    })
  },
  onChangeYear(e){
    year = e.detail;
    console.log(year);
    if(year!=0){
      this.selectComponent('#monthCheck').set(
        {
          disabled: false,
        }
      )
    };
  },
  getRecords(){
    var _this=this;
    wx.request({
      url:  'http://localhost:5000/api/risk/makeMonthlyData/?year=' + year + '&month=' + month,
      header: {
        'contenty-type': 'application/json'
      },
      success(res) {
        console.log('data', res);
        _this.setData({
          riskReport: res.data.records
        })
      }
    })
  },
  onChangeMonth(e){
    month = e.detail;
    console.log(month);
    if(month!=0){
      wx.showToast({
        title: '载入数据中',
        icon: 'loading',
        duration: 500
      })
      this.getRecords();
    }
  },
  downLoadAnalysisReport(){
    if(year==0||month==0){
      wx.showToast({
        icon:"none",
        title: '请选择具体年月',
        duration: 2000
      })
    }
    else{
        var urlData = 'http://localhost:5000/api/risk/makeMonthlyFile/?year=' + year + '&month=' + month;
          wx.setClipboardData({
            data: urlData + "，点击链接查看月度风险预警报告【来自供应链安全评估与施策仿真】",
            success(res) {
              wx.getClipboardData({
                success(sres) {
                  wx.showToast({
                    icon:"warn",
                    title: '报告链接已复制',
                    duration: 2000
                  })
                  console.log(sres.data) // data
                }
              })
            }
          })

         
      }
  }
});
