//堵点不是风险值


//颜色 有结果


//增加数据输入的入口  点击
//解释指数的来源
//堵点分析 关联增加
//施策对象-堵点 多个原因  税 融资 等
//原材料等供应
//匹配增加一级
//具体数字不用
//颜色 图谱 解决某一个问题 与施策相关


//施策对象不是企业  是事件
//  中物联的施策  库存安全等  施策手段 公式


//每选一个政策出一个图谱，组合政策。精准施策的评估方法。
//评估方法  
// 

//index.js
//获取应用实例


//1.学习历史数据 下拉框 成功案例12345 历史施策 失败的案例12345 。参考
//2 . 施策 每选一个出现一个联动的效果 选两个效果  单个-多个-联动   主动选择  正面效果 负面效果 决策支持  名字改 敏感词  金融施策  政府施策  国家政策
//3  政策  从企业数据  深度学习    基于案例推理


//施策对象
//安全 风险的区别
//完整的例子 安全指数怎么计算，断链，库存、价格，堵点
//不卖设备、国家政策，政策匹配度模型

const g_graph = {
    'nodes': [

        {
        'id': '43',
        'category': 2,
        'risk': 74,
        'name': '青海江仓能源发展有限责任公司',
        'relation': '主体节点',
        'label': {
            'normal': {
                'show': true
            }
        },
        'fixed': true,
        'x': 200,
        'y': 300,
        'symbolSize': 70
    }, {
        'id': '44',
        'category': 2,
        'risk': 41,
        'name': '肥城矿业集团有限责任公司',
        'relation': '直接相关',
        'symbolSize': 50,
        'label': {
            'normal': {
                'show': true
            }
        },
        'draggable': true
    }, {
        'id': '36',
        'category': 2,
        'risk': 51,
        'name': '西宁特殊钢股份有限公司',
        'relation': '直接相关',
        'symbolSize': 50,
        'label': {
            'normal': {
                'show': true
            }
        },
        'draggable': true
    }, {
        'id': '42',
        'category': 2,
        'risk': 60,
        'name': '青海西钢新材料有限公司',
        'relation': '直接相关',
        'symbolSize': 50,
        'label': {
            'normal': {
                'show': true
            }
        },
        'draggable': true
    }, {
        'id': '46',
        'category': 2,
        'risk': 23,
        'name': '格尔木西钢商贸有限公司',
        'relation': '间接关联',
        'symbolSize': 50,
        'label': {
            'normal': {
                'show': true
            }
        },
        'draggable': true
    }, {
        'id': '47',
        'category': 2,
        'risk': 30,
        'name': '湟中西钢矿业开发有限公司',
        'relation': '间接关联',
        'symbolSize': 50,
        'label': {
            'normal': {
                'show': true
            }
        },
        'draggable': true
    }, {
        'id': '39',
        'category': 2,
        'risk': 29,
        'name': '青海西钢再生资源开发利用有限公司',
        'relation': '间接关联',
        'symbolSize': 50,
        'label': {
            'normal': {
                'show': true
            }
        },
        'draggable': true
    }, {
        'id': '37',
        'category': 2,
        'risk': 67,
        'name': '青海西钢矿业开发有限责任公司',
        'relation': '间接关联',
        'symbolSize': 50,
        'label': {
            'normal': {
                'show': true
            }
        },
        'draggable': true
    }, {
        'id': '38',
        'category': 2,
        'risk': 32,
        'name': '青海迅捷物流股份有限公司',
        'relation': '间接关联',
        'symbolSize': 50,
        'label': {
            'normal': {
                'show': true
            }
        },
        'draggable': true
    }],
    'links': [
        
        {
            'id': '51',
            'source': '51',
            'target': '43',
            'lineStyle': {
                'normal': {}
            },
            'name': '指导',
            'value': 1
        }, 
        {
            'id': '52',
            'source': '52',
            'target': '43',
            'lineStyle': {
                'normal': {}
            },
            'name': '指导',
            'value': 1
        }, 
        {
            'id': '53',
            'source': '53',
            'target': '43',
            'lineStyle': {
                'normal': {}
            },
            'name': '指导',
            'value': 1
        },  {
            'id': '54',
            'source': '51',
            'target': '36',
            'lineStyle': {
                'normal': {}
            },
            'name': '指导',
            'value': 1
        },  {
            'id': '55',
            'source': '52',
            'target': '42',
            'lineStyle': {
                'normal': {}
            },
            'name': '指导',
            'value': 1
        },  {
            'id': '56',
            'source': '53',
            'target': '36',
            'lineStyle': {
                'normal': {}
            },
            'name': '指导',
            'value': 1
        }, 
        {
        'id': '44',
        'source': '43',
        'target': '44',
        'lineStyle': {
            'normal': {}
        },
        'name': '合作',
        'value': 1
    }, {
        'id': '36',
        'source': '43',
        'target': '36',
        'lineStyle': {
            'normal': {}
        },
        'name': '合作',
        'value': 1
    }, {
        'id': '42',
        'source': '43',
        'target': '42',
        'lineStyle': {
            'normal': {}
        },
        'name': '合作',
        'value': 1
    }, {
        'id': '46',
        'source': '36',
        'target': '46',
        'lineStyle': {
            'normal': {}
        },
        'name': '合作',
        'value': 1
    }, {
        'id': '47',
        'source': '36',
        'target': '47',
        'lineStyle': {
            'normal': {}
        },
        'name': '合作',
        'value': 1
    }, {
        'id': '39',
        'source': '36',
        'target': '39',
        'lineStyle': {
            'normal': {}
        },
        'name': '合作',
        'value': 1
    }, {
        'id': '37',
        'source': '36',
        'target': '37',
        'lineStyle': {
            'normal': {}
        },
        'name': '合作',
        'value': 1
    }, {
        'id': '38',
        'source': '36',
        'target': '38',
        'lineStyle': {
            'normal': {}
        },
        'name': '合作',
        'value': 1
    }]
}



//操作后显示的变量  g_graph不改变  因为浅拷贝的问题 两个变量


const app = getApp()
var that = this;
const citys = {
    '汽车2': ['国际', '国内', '产业链'],
    '芯片': ['国际', '国内', '产业链'],
    '汽车': ['国际', '国内', '产业链'],
    '牛奶': ['国际', '国内', '产业链'],
    '大米': ['国际', '国内', '产业链'],
    '大豆': ['国际', '国内', '产业链'],
    '蔗糖': ['国际', '国内', '产业链'],
    '其他': ['国际', '国内', '产业链'],
};


const citys2 = {
    '普惠金融类': ['国家部门', '发改部门', '银行系统', '税务系统', '地方政府'],
    '税收优惠类': ['国家部门', '发改部门', '银行系统', '税务系统', '地方政府'],
    '疏解政策类': ['国家部门', '发改部门', '银行系统', '税务系统', '地方政府'],
};



const subItems = [
    '稀土金属矿',
    '钍矿砂及其精矿',
    '混合碳酸稀土',
]


import * as echarts from '../../ec-canvas/echarts';
import Toast from '@vant/weapp/toast/toast';
let chart = null
let chart2 = null


let comp_id = null;



var categories = [{
    name: "影响节点"
}, {
    name: "次生影响节点"
}, {
    name: "正常节点"
} ,{
    name: "政策部门"
},{
    name: "主管部门"
},{
    name: "执行部门"
},

];

//企業節點
let options = {
    title: {
        text: '风险知识图谱',
        top: 'bottom',
        left: 'right'
    },
    roam: true,
    tooltip: {
        formatter:function(x){
            return x.name
        }
    },
    legend: [{
        height:10,
        left:'center',
        itemGap:15,
        // padding:'10px',
        textStyle:{
            // color:'#fff',
            color:(params)=>(params),
            fontSize:13,
        },

        
        // selectedMode: 'single',
        data: categories.map(function (a) {
            return a.name;
        })
    }],
    animationDuration: 1500,
    animationEasingUpdate: 'quinticInOut',



    color:['#fc853e','#28cad8','#6f4242','#FF0000','#FF00FF','#9F5F9F',],

    series: [{
        name: 'risk graph',
        type: 'graph',
        layout: 'force',
        symbolSize: 60,
        data: [],
        links: [],
        categories: categories,
        roam: true,
        // label: {
        //     'normal': {
        //         'show': true
        //     }
        // },
        // draggable: true,
        itemStyle: {
            normal: {
                symbolSize: 50,
                
                
                // show: true,
                borderColor: '#fff',
                borderWidth: 1,
                shadowBlur: 10,
                shadowColor: 'rgba(0, 0, 0, 0.3)',
                opacity:0.9
            }
        },
        label: {
            position: '',
            formatter: '{b}'
        },

        //点击显示周边关系
        focusNodeAdjacency: true,
        lineStyle: {
            show:true,
            color: 'source',
            curveness: 0.3
        },
        emphasis: {
            lineStyle: {
                width: 10
            }
        },

        force: {
            // repulsion: 80,
            // gravity: 0.01,
            edgeLength: [50, 200],

            // 力引导图基本配置
            // initLayout: , // 力引导的初始化布局，默认使用xy轴的标点
            repulsion: 200, // 节点之间的斥力因子。支持数组表达斥力范围，值越大斥力越大。
            gravity: 0.02, // 节点受到的向中心的引力因子。该值越大节点越往中心点靠拢。
            // edgeLength: 200, // 边的两个节点之间的距离，这个距离也会受 repulsion影响 。值越大则长度越长
            layoutAnimation: true // 因为力引导布局会在多次迭代后才会稳定，这个参数决定是否显示布局的迭代动画
            // 在浏览器端节点数据较多（>100）的时候不建议关闭，布局过程会造成浏览器假死。 

        },
        edgeSymbol: ['circle', 'arrow'],//边两端的标记类型
        edgeSymbolSize:[4,8],//边两端的标记大小
        edgeLabel: {
            normal: {
                show: true,
                textStyle: {
                    fontSize: 12,
                    color:"white"
                },
        
                formatter: "{c}"
            }
        },



    }]
};

//对历史指数的表
function initChart(canvas, width, height, dpr) {
    chart = echarts.init(canvas, null, {
        width: 350,
        height: 300,
        devicePixelRatio: dpr // 像素
    });
    canvas.setChart(chart);
    var option = {
        title: {
            text: '历史指数',
            left: 'center'
        },
        series: [{
            data: [820, 932, 901, 934, 1290, 1330, 1320],
            type: "line"
        }],
        xAxis: {
            type: 'category',
            data: ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"]
        },
        yAxis: {}
    }
    chart.setOption(option)
    return chart;
}


function initChartrd(canvas, width, height, dpr) {

  


    const chart = echarts.init(canvas, null, {
      width: width,
      height: height,
      devicePixelRatio: dpr // new
    });
    canvas.setChart(chart);

    console.log("hereee2")


  
    var option = {
      backgroundColor: "#ffffff",
      xAxis: {
        show: false
      },
      yAxis: {
        show: false
      },
      radar: {
        // shape: 'circle',
        indicator: [{
          name: '食品',
          max: 500
        },
        {
          name: '玩具',
          max: 500
        },
        {
          name: '服饰',
          max: 500
        },
        {
          name: '绘本',
          max: 500
        },
        {
          name: '医疗',
          max: 500
        },
        {
          name: '门票',
          max: 500
        }
        ]
      },
      series: [{
        name: '预算 vs 开销',
        type: 'radar',
        data: [{
          value: [430, 340, 500, 300, 490, 400],
          name: '预算'
        },
        {
          value: [300, 430, 150, 300, 420, 250],
          name: '开销'
        }
        ]
      }]
    };
  

    chart.setOption(option);

    console.log("huatu")


    return chart;
}

//画图的
function initChart2(canvas, width, height, dpr) {

    console.log("initchart2,")

    chart2 = echarts.init(canvas, null, {
        width: width,
        height: height,
        devicePixelRatio: dpr // 像素
    });

    console.log("hereeee")
    canvas.setChart(chart2);

    console.log(chart2)

    options.series[0].data = g_graph.nodes;
    options.series[0].links = g_graph.links;

        // console.log("optionn",options)

        //画图
        setTimeout(function () {
            chart2.setOption(options);
          }), 2000;


    return chart2;
}

//柱状图
function initChart3(canvas, width, height, dpr) {
    const chart = echarts.init(canvas, null, {
      width: width,
      height: height,
      devicePixelRatio: dpr // new
    });
    canvas.setChart(chart);
   
    var option = {
      title: {
        text: '测试下面legend的红色区域不应被裁剪',
        left: 'center'
      },
      legend: {
        data: ['A', 'B', 'C'],
        top: 50,
        left: 'center',
        backgroundColor: 'red',
        z: 100
      },
      grid: {
        containLabel: true
      },
      tooltip: {
        show: true,
        trigger: 'axis'
      },
      xAxis: {
        type: 'category',
        boundaryGap: false,
        data: ['周一', '周二', '周三', '周四', '周五', '周六', '周日'],
        // show: false
      },
      yAxis: {
        x: 'center',
        type: 'value',
        splitLine: {
          lineStyle: {
            type: 'dashed'
          }
        }
        // show: false
      },
      series: [{
        name: 'A',
        type: 'line',
        smooth: true,
        data: [18, 36, 65, 30, 78, 40, 33]
      }, {
        name: 'B',
        type: 'line',
        smooth: true,
        data: [12, 50, 51, 35, 70, 30, 20]
      }, {
        name: 'C',
        type: 'line',
        smooth: true,
        data: [10, 30, 31, 50, 40, 20, 10]
      }]
    };
   
    chart.setOption(option);
    return chart;
  }
 

var year = 2021;
var month = 7;

var datard = [
    { name: '库存风险', value: 50, color: '#80e0ed' },
    { name: '物流风险', value: 40, color: '#9197ed' },
    { name: '价格风险', value: 30, color: '#eddf5c' },
    { name: '商贸风险', value: 60, color: '#e4ff99' },
    { name: '生产风险', value: 50, color: '#baffad' },
    { name: '销售风险', value: 20, color: '#afee9d' }
  ]
  

Page({
    data: {

       //柱状图
        canvasInfo:{},
        dataList: [{ title: "17岁以下", value: 0 }, { title: "18-24岁", value: 8 }, { title: "25-29岁", value: 9 }, { title: "30-39岁", value: 7 }, { title: "40-49岁", value: 3 }],


        //控制公式是否展示
        isShowads:'none',
        //控制可视化
        isShowads2:'none',

        ispolicy1:false,
        ispolicy2:false,
        ispolicy3:false,



        //饼状图

        g_ec: {
            onInit: initChart2
        },
        rd_ec: {
            onInit: initChartrd
        },

        //柱状图
        z_ec: {
            onInit: initChart3
          },

        // g_ec2: {
        //     onInit: initChart3
        // },

        g_loading: true,
        g_show: false,
        g_type: 1,
        g_entity_id: 1,

        //图谱上方描述信息
        g_comp: [1, "纽仕兰有限公司", "纽仕兰乳业公司的主要产品有全脂牛奶、低脂牛奶和婴幼儿奶粉", "https://markdown-pic-blackboxo.oss-cn-shanghai.aliyuncs.com/uuhl.png", 77, 90, 125795],
        g_hiddenn: false,

        

        //上述是graph.js中的

        //政策默认显示一个
        // p2_hidden: true,
        // p3_hidden: true,
        add_hidden:false,


        //政策选择
        list_p:[1],

        result1 :"请先选择",
        result2 :"",
        result3 :"",
        result4 :"请先选择",
        result5 :"",
        result6 :"",
        result7 :"请先选择",
        result8 :"",
        result9 :"",
        result10 :"请先选择",
        result11 :"",
        result12 :"",

        shudian1:"",
        shudian2:"",
        shudain3:"",

        // type1:高风险,
        // type2:中风险,
        // type3:81,
        // type4:69,
        reason1:" 大豆经济具有以下特征：中国是全球最大的大豆消费国之一，主要用途为饲料和食用油；大豆生产受到气候变化影响显著，并且价格波动较大。",
        reason2:" 消费层面：《关于促进汽车消费的若干政策》： 中国财政部发布的政策文件，包括关于汽车购置税减免和购车补贴等内容，以促进汽车市场需求。",
        reason3:"《新能源汽车产业发展规划》： 该规划由中国国家发展和改革委员会（国家发改委）和工业和信息化部（工信部）共同发布，关注新能源汽车产业的发展，包括电动汽车、电池技术和充电基础设施。",
        reason4:"《关于进一步支持新能源汽车推广应用的通知》： 该通知由财政部发布，包括关于新能源汽车购置税减免和财政补贴政策的细则。",

        fengxianleixing: "",

        zhengce1 :"",
        zhengce2 :"",
        zhengce3 :"",
        zhengce4 :"",

        isLoaded: false,
        isDisplosed: false,
        ec: {
            lazyLoad: true
        },

        risk: 60,
        loading: true,
        loads: true,
        blockDesc: [],
        desc: [],

        //控制菜单是否展示
        show: false,
        show2: false,
        show3: false,
        show4: false,

        // xiaoguo0: 0,
        // xiaoguo1: 0,

        // xiaoguo2: 0,
        // xiaoguo3: 0,


        tableShow: false,
        columns: [{
                values: Object.keys(citys),
                className: 'column1',
                disabled: true
            },
            {
                values: citys['牛奶'],
                className: 'column2',
                defaultIndex: 0
            },
            {
                values: ['一月', '二月', '三月', '四月', '五月', '六月', '七月', '八月', '九月'],
                className: 'column3',
                defaultIndex: 1
            }
        ],

        columns2: [{
                values: Object.keys(citys2),
                className: 'column1',
                disabled: true
            },
            {
                values: citys2['普惠金融类'],
                className: 'column2',
                defaultIndex: 0
            },
              {
                values: ['贷款', '政策保险', '政府补贴'],
                className: 'column3',
                defaultIndex: 1
              }
        ],






        companys: [],
        projects: [],
        consensuses: [],
        activeNames: ['0'],
        analysisResultActiveNames: ['0'],
        credit: [],
        basic: [],
        activeBasic: ['1', '2'],
        active: 0,
        activeEntityType: 0,
        comp: {},
        safetyIndex: [],

        preTab0Value1: '',

        //施策的数组
        tab0Value:['请选择','请选择','请选择','请选择','请选择','请选择','请选择','请选择','请选择'],


        tab0Value1: '汽车',
        tab0Value2: '国内',
        tab0Value3: '二月',

        tab0Value4: '请选择',
        tab0Value5: '请选择',
        tab0Value6: '请选择',

        tab0Value7: '税收优惠类',
        tab0Value8: '税务部门',
        tab0Value9: '减税',

        tab0Value10: '疏解政策类',
        tab0Value11: '地方政府',
        tab0Value12: '疏解',



        //堵点企业
        blockEntities: [

        ],
        //第二页
        blockEntities2: [

        ],
        blockEntities2Value: 1,
        blockEntity: {},
        riskReport: [],
        carryEntity: {},
        relatedBlockEntities: [

        ],
        blockEntityUserRemarks: [],
        carryEntityUserRemarks: [],
        effect_nums: 0,
        relatedCarryEntities: [],

        //建议疏点 tab1
        carryEntities: [

        ],


        fangzhenEntities:[],



        reply: false,
        customize: '',
        tab2CarryEntities: [],
        tab2CarryEntitiesValue: 0,

        customizeCarryEntityId: [],
        customizeCarryEntity1: '',
        customizeCarryEntity2Array: [], //默认显示0个
        customizeCarryEntity2InputVal: [], //所有input的内容

        policyReply: false,


        //政策匹配里的参数  施策用
        tab2Policy: [],
        tab2PolicyValue: 0,
        tab2Policy2: [],
        tab2PolicyValue2: 0,
        tab2Policy3: [],
        tab2PolicyValue3: 0,
        tab2Policy4: [
            {
            text: '汽车供应链1',
            value: 0
            },
            {
                text: '汽车供应链2',
                value: 1
             },
             {
                text: '汽车供应链3',
                value: 2
             },
             

        ],
        tab2PolicyValue4: 0,
        customizePolicy1: '',
        customizePolicy2Array: [], //默认显示0个
        customizePolicy2InputVal: [], //所有input的内容

        methodReply: false,

        //政策匹配的参数   施策用的方法  第二栏
        tab2Method: [],
        tab2MethodValue: 0,
        tab2Method2: [],
        tab2MethodValue2: 0,
        tab2Method3: [],
        tab2MethodValue3: 0,

        tab2MethodValue4: 0,

        customizeMethod1: '',
        customizeMethod2Array: [], //默认显示0个
        customizeMethod2InputVal: [], //所有input的内容

        // 施策分析下载按钮是否禁用，初始禁用
        downLoadAnalysisFileStatus: true,
        // 月度数据报告下载按钮是否禁用，初始禁用
        downLoadAnalysisReoprtStatus: true,

        // 风险预警
        riskWarning: '高风险',
        subItemVisible: false,
        subItemColumns: [{
            values: subItems,
            className: 'column1',
        }],
        chosenSupplyItem: '稀土金属矿',
        risk_level: '低风险',
        // 是否显示风险预警和生产安全度提示
        riskVisible: false,
 
        // 是否显示弹出层
        formulaPopupVisible: false,

        // 以下与popup中的数据来源有关
        supplyQuantity: [],
        activeCollapse: [],
        consumeQuantity: [],
        stockQuantity: [],
        priceQuantity: [],
        priceQuantity: [],
        supplyVisible: false,
        consumeVisible: false,

        chosenIndexTitle: '',

        historyIndex: {},
        isLoaded: false,

        // 指数解读相关
        msgVisible: false,
        msg: [],
        yearOption: [{
                text: '请选择年份',
                value: 0
            },
            {
                text: '2021年',
                value: 2021
            },
        ],
        monthOption: [{
                text: '请选择月份',
                value: 0
            },
            {
                text: '一月',
                value: 1
            },
            {
                text: '二月',
                value: 2
            },
            {
                text: '三月',
                value: 3
            },
            {
                text: '四月',
                value: 4
            },
            {
                text: '五月',
                value: 5
            },
            {
                text: '六月',
                value: 6
            },
            {
                text: '七月',
                value: 7
            },
        ],
        year: 2021,
        month: 7,
        buttonDisabled: true,
    },
    jumpToWeb() {
        wx.navigateTo({
            url: '../out/out',
        })
        console.log('这里用来跳转到外网')
    },

    seegongshi() {
        if(this.data.isShowads=='none')
        this.setData({
            isShowads:'block'
        })

        else 
        this.setData({
            isShowads:'none'
        })


        console.log('这里用来查看公式')

    },

    seekeshihua() {
        if(this.data.isShowads2=='none')
        this.setData({
            isShowads2:'block'
        })

        else 
        this.setData({
            isShowads2:'none'
        })


        console.log('这里用来查看keshihua')

    },

    chakantupu() {
        if(this.data.g_hiddenn==false){
            this.setData({
           
                g_hiddenn:true,
    
            });
        }else{
            this.setData({
           
                g_hiddenn:false,
    
            });
        }
       

    },

    jumpToTab1() {
        this.setData({
            formulaPopupVisible: false,
            active: 1,
        })
    },
    jumpToTab2() {
        this.setData({
            formulaPopupVisible: false,
            active: 2,
        })
    },
    jumpToTab3() {
        this.setData({
            formulaPopupVisible: false,
            active: 3,
            // tab2MethodValue:
            list_p:[1,2,3],
            add_hidden:true,

        
            'tab0Value[0]': this.data.tab2Policy[0].text,
            'tab0Value[1]': '国家部门',
            'tab0Value[2]': this.data.tab2Method[0].text,
            'tab0Value[3]': this.data.tab2Policy2[0].text,
            'tab0Value[4]': '发改部门',
            'tab0Value[5]': this.data.tab2Method2[0].text,
            'tab0Value[6]': this.data.tab2Policy3[0].text,
            'tab0Value[7]': '政府部门',
            'tab0Value[8]': this.data.tab2Method3[0].text,

               


        })
    },
    // clickfanhui(){
    //     console.log("dd")
    //     this.setData({
    //         active: 2,
    //       });
    // },
    showPopup() {
        this.setData({
            show: true,
        });
    },
    showPopup2(e) {
        console.log("showpop")
        this.setData({
            show2: true,
            // active:4
            g_hiddenn:true,
        });

    },

    addzhengce(){
        console.log("addzhengce")
        var listp=this.data.list_p
        if(listp.length<3){

            listp.push(1)
            // console.log(listp)
            //底层动态渲染前端
            //最多三个 隐藏
            if(listp.length==3) 
            this.setData({
                list_p:listp,
                add_hidden:true
            })

            else
            this.setData({
                list_p:listp
            })
        }
        
        

    },



    showPopup3(e) {
        console.log("indexx",e.currentTarget.dataset.index);

        if(e.currentTarget.dataset.index==2){
            this.setData({
                show3: true,
                g_hiddenn:true,
                ispolicy3:true,    //选择了第三个政策，改变变量，出图
                ispolicy2:false,
                ispolicy1:false,
            });

        }else if(e.currentTarget.dataset.index==0){
            this.setData({
                show3: true,
                g_hiddenn:true,
                ispolicy3:false,    
                ispolicy2:false,
                ispolicy1:true,
            });

        }else if(e.currentTarget.dataset.index==1){
            this.setData({
                show3: true,
                g_hiddenn:true,
                ispolicy3:false,    //选择了第三个政策，改变变量，出图
                ispolicy2:true,
                ispolicy1:false,
            });

        }

        

    },
    showPopup4() {
        this.setData({
            show4: true,
        });
    },
    // setOption(chart) {
    //     const option = {
    //         title: {
    //             text: '指数历史数据',
    //             left: 'center',
    //         },
    //         tooltip: {
    //             trigger: 'axis'
    //         },
    //         color: ['#37a2da', '#32c5e9', '#67e0e3'],
    //         grid: {
    //             left: 20,
    //             right: 20,
    //             bottom: 15,
    //             top: 40,
    //             containLabel: true
    //         },
    //         xAxis: [{
    //             type: 'category',
    //             axisLine: {
    //                 lineStyle: {
    //                     color: '#999'
    //                 }
    //             },
    //             axisLabel: {
    //                 color: '#666'
    //             },
    //             data: this.data['historyIndex']['xAxis']
    //         }],
    //         yAxis: {},
    //         series: [{
    //             data: this.data['historyIndex']['data'],
    //             type: 'line'
    //         }]
    //     };
    //     chart.setOption(option);
    // },
    updateHistoryIndex() {
        var _this = this;
        this.data.preTab0Value1 = this.data.tab0Value1
        wx.request({
            url: 'http://localhost:5000/api/risk/index/history',
            data: {
                chain: _this.data.tab0Value1,
            },
            success(res) {
                _this.setData({
                    historyIndex: res.data,
                    isLoaded: true
                })
                setTimeout(() => {
                    _this.ecComponent = _this.selectComponent("#history_line")
                    _this.ecComponent.init((canvas, width, height, dpr) => {
                        // 获取组件的 canvas、width、height 后的回调函数
                        // 在这里初始化图表
                        const chart = echarts.init(canvas, null, {
                            width: width,
                            height: height,
                            devicePixelRatio: dpr // new
                        });
                        _this.setOption(chart);
                        // // 将图表实例绑定到 this 上，可以在其他成员函数（如 dispose）中访问
                        // this.chart = chart;

                        // 注意这里一定要返回 chart 实例，否则会影响事件处理等
                        return chart;
                    })
                }, 1000)
            }
        })
    },
    loadHistoryIndex(event) {
        // console.log('event', event)
        var _this = this;

        if (event['detail']['title'] === '历史数据') {
            if (this.data.preTab0Value1 !== this.data.tab0Value1) {
                _this.updateHistoryIndex()
            }
        }
        // wx.request({
        //   url: 'http://localhost:5000/api/risk/index/history',
        //   // data: {
        //   //   type: '',
        //   //   chain: '',
        //   // },
        //   success(res) {
        //     console.log('history index', res)
        //   }

        // });
    },
    // onReady: function() {
    //   this.data.ecComponent = this.selectComponent("#history_line")
    // },
    onClose() {
        this.setData({
            show: false
        });
    },
    onClose2() {
        this.setData({
            show2: false
        });
    },
    onClose3() {
        this.setData({
            show3: false
        });
    },
    onClose4() {
        this.setData({
            show4: false
        });
    },
    onPickerChange(event) {
        const {
            picker,
            value,
            index
        } = event.detail;
        if (index == 0) {
            picker.setColumnValues(1, citys[value[0]]);
            picker.setColumnIndex(1, 0);
        }
        this.setData({
            tableShow: true
        })
    },

    onPickerChange2(event) {
        const {
            picker,
            value,
            index
        } = event.detail;
        if (index == 0) {
            picker.setColumnValues(1, citys2[value[0]]);
            picker.setColumnIndex(1, 0);
        }
        this.setData({
            tableShow: true
        })
    },




    moveHandle() {

    },
    // 供应链选择
    onConfirm(event) {
        var _this = this;
        const {
            picker,
            value,
            index
        } = event.detail;

        wx.showLoading({
            title: '请稍候...',
            mask: true // 显示透明蒙层，防止触摸穿透
          });
      
          // 设置定时器，假设我们需要等待3秒
          setTimeout(() => {
            // 隐藏加载提示框
            wx.hideLoading();
      
            // 这里执行你的任务
            console.log('延时任务执行了');
            _this.setData({
                tab0Value1: value[0],
                tab0Value2: value[1],
                tab0Value3: value[2],
                show: false,
                tableShow: true
            });
            _this.getRiskValue();
            _this.getBlockEntities();
            _this.getCarryEntities();
    
            //获取tab2所有堵点
            _this.getAllBlockEntities();
            _this.getBlockEntityDetail();
            _this.getBlockage();
    
            //获取tab3所有疏点
            _this.getAllCarryEntities();
            // 获取决策数据源
            _this.getCalBasic()
    
            // 获取建议施策
            _this.getBlockInterpretation();
      
            // 可以是跳转页面，更新数据等操作
            // wx.navigateTo({ url: '/pages/your-page/your-page' });
          }, 2000);

        
    },

    // 单个施策选择
    onConfirm2(event) {
        //index判断第几个
        console.log("ondetail", event.detail);

        var _this = this;
        const {
            picker,
            value,
            index
        } = event.detail;


        console.log('选择了什么',value)

           //重置元素
           _this.setData({
            tab0Value4: value[0],
            tab0Value5: value[1],
            tab0Value6: value[2],
            show2: false,
            tableShow: true,
            g_hiddenn:false,
        })


        Toast({
            type: 'loading',
            message: '计算单个政策的影响中...请稍后……',
            duration: 3000,
            onClose: () => {
                Toast({
                    type: 'success',
                    message: '已计算出单个政策正面和负面收益！',
                    duration: 3000,
                  }); 

                //    //重置元素
                // _this.setData({
                //     tab0Value4: value[0],
                //     tab0Value5: value[1],
                //     tab0Value6: value[2],
                //     show2: false,
                //     tableShow: true,
                //     g_hiddenn:false,
                // })


                        //一定要这样初始化 不能直接=  浅拷贝
        var temp_graph = {
            'nodes': [
                {
                    'id': '51',
                    'category': 3,
                    'risk': 41,
                    'name': _this.data.tab0Value5,
                    'relation': '直接相关',
                    'symbolSize': 80,
                    'label': {
                        'normal': {
                            'show': true
                        }
                    },
                    'draggable': true
                 },
                 {
                    'id': '52',
                    'category': 4,
                    'risk': 41,
                    'name': '主管部门',
                    'relation': '直接相关',
                    'symbolSize': 80,
                    'label': {
                        'normal': {
                            'show': true
                        }
                    },
                    'draggable': true
                 },{
                    'id': '53',
                    'category': 5,
                    'risk': 41,
                    'name': '执行部门',
                    'relation': '直接相关',
                    'symbolSize': 80,
                    'label': {
                        'normal': {
                            'show': true
                        },
                    'draggable': true
                 }}, 
                {
                'id': '43',
                'category': 2,
                'risk': 74,
                'name': '青海江仓能源发展有限责任公司',
                'relation': '主体节点',
                'label': {
                    'normal': {
                        'show': true
                    }
                },
                'fixed': true,
                'x': 200,
                'y': 300,
                'symbolSize': 70
            }, {
                'id': '44',
                'category': 2,
                'risk': 41,
                'name': '肥城矿业集团有限责任公司',
                'relation': '直接相关',
                'symbolSize': 50,
                'label': {
                    'normal': {
                        'show': true
                    }
                },
                'draggable': true
            }, {
                'id': '36',
                'category': 2,
                'risk': 51,
                'name': '西宁特殊钢股份有限公司',
                'relation': '直接相关',
                'symbolSize': 50,
                'label': {
                    'normal': {
                        'show': true
                    }
                },
                'draggable': true
            }, {
                'id': '42',
                'category': 2,
                'risk': 60,
                'name': '青海西钢新材料有限公司',
                'relation': '直接相关',
                'symbolSize': 50,
                'label': {
                    'normal': {
                        'show': true
                    }
                },
                'draggable': true
            }, {
                'id': '46',
                'category': 2,
                'risk': 23,
                'name': '格尔木西钢商贸有限公司',
                'relation': '间接关联',
                'symbolSize': 50,
                'label': {
                    'normal': {
                        'show': true
                    }
                },
                'draggable': true
            }, {
                'id': '47',
                'category': 2,
                'risk': 30,
                'name': '湟中西钢矿业开发有限公司',
                'relation': '间接关联',
                'symbolSize': 50,
                'label': {
                    'normal': {
                        'show': true
                    }
                },
                'draggable': true
            }, {
                'id': '39',
                'category': 2,
                'risk': 29,
                'name': '青海西钢再生资源开发利用有限公司',
                'relation': '间接关联',
                'symbolSize': 50,
                'label': {
                    'normal': {
                        'show': true
                    }
                },
                'draggable': true
            }, {
                'id': '37',
                'category': 2,
                'risk': 67,
                'name': '青海西钢矿业开发有限责任公司',
                'relation': '间接关联',
                'symbolSize': 50,
                'label': {
                    'normal': {
                        'show': true
                    }
                },
                'draggable': true
            }, {
                'id': '38',
                'category': 2,
                'risk': 32,
                'name': '青海迅捷物流股份有限公司',
                'relation': '间接关联',
                'symbolSize': 50,
                'label': {
                    'normal': {
                        'show': true
                    }
                },
                'draggable': true
            }],
            'links': [
                {
                            'id': '51',
                            'source': '51',
                            'target': '43',
                            'lineStyle': {
                                'normal': {}
                            },
                            'name': '指导',
                            'value': 1
                        }, 
                        {
                            'id': '52',
                            'source': '52',
                            'target': '43',
                            'lineStyle': {
                                'normal': {}
                            },
                            'name': '指导',
                            'value': 1
                        }, 
                        {
                            'id': '53',
                            'source': '53',
                            'target': '43',
                            'lineStyle': {
                                'normal': {}
                            },
                            'name': '指导',
                            'value': 1
                        },  {
                            'id': '54',
                            'source': '51',
                            'target': '36',
                            'lineStyle': {
                                'normal': {}
                            },
                            'name': '指导',
                            'value': 1
                        },  {
                            'id': '55',
                            'source': '52',
                            'target': '42',
                            'lineStyle': {
                                'normal': {}
                            },
                            'name': '指导',
                            'value': 1
                        },  {
                            'id': '56',
                            'source': '53',
                            'target': '36',
                            'lineStyle': {
                                'normal': {}
                            },
                            'name': '指导',
                            'value': 1
                        }, 
                
                {
                'id': '44',
                'source': '43',
                'target': '44',
                'lineStyle': {
                    'normal': {}
                },
                'name': '合作',
                'value': 1
            }, {
                'id': '36',
                'source': '43',
                'target': '36',
                'lineStyle': {
                    'normal': {}
                },
                'name': '合作',
                'value': 1
            }, {
                'id': '42',
                'source': '43',
                'target': '42',
                'lineStyle': {
                    'normal': {}
                },
                'name': '合作',
                'value': 1
            }, {
                'id': '46',
                'source': '36',
                'target': '46',
                'lineStyle': {
                    'normal': {}
                },
                'name': '合作',
                'value': 1
            }, {
                'id': '47',
                'source': '36',
                'target': '47',
                'lineStyle': {
                    'normal': {}
                },
                'name': '合作',
                'value': 1
            }, {
                'id': '39',
                'source': '36',
                'target': '39',
                'lineStyle': {
                    'normal': {}
                },
                'name': '合作',
                'value': 1
            }, {
                'id': '37',
                'source': '36',
                'target': '37',
                'lineStyle': {
                    'normal': {}
                },
                'name': '合作',
                'value': 1
            }, {
                'id': '38',
                'source': '36',
                'target': '38',
                'lineStyle': {
                    'normal': {}
                },
                'name': '合作',
                'value': 1
            }]
        }


         //修改图节点关系
         if(value[0]=='普惠金融类'){

            //出文字效果先
            _this.setData({
              result1: "1：供应方面： 政府出台政策鼓励大豆产业和可持续发展，可能会提高供应链的技术水平和质量标准。这有助于降低供应链的质量风险" + String( Math.round(Math.random()*20) ) +" %",

              result2: "2：库存方面： 政府的大豆产业政策可能有助于平衡市场需求，减少外部不稳定影响。",
              
              result3: "3：价格方面：政府政策鼓励大豆种植，这可能降低种植成本，有助于稳定价格。",
              
              result4: "1：供应方面：贸易争端和政策变化可能导致大豆供应链的不稳定性，影响供应的可靠性。" + String( Math.round(Math.random()*20) ) +" %",
              
              result5: "2：库存方面： 市场波动和需求不确定性可能导致大豆库存风险。政策的变化可能对库存管理产生不利影响。",
              
              result6: "3：价格方面：贸易问题和政策变化可能导致大豆价格波动，尤其是对于进口大豆，这可能影响国内市场的价格。",
              
              result7: "1：物流：中国政府支持基础设施建设和国际贸易，可能改善大豆物流效率。政府政策可能有助于提高大豆运输的可靠性。",
              
              result8: "2:商贸： 政府出台政策以促进大豆产品消费，可能提高市场销售，有利于大豆商贸。贸易协定和政策的稳定性可能促进大豆的国际贸易。",
              
              result9: "3：政策环境：政府在农业补贴、土地使用等方面的支持可以增强大豆生产者的积极性，从而推动整个大豆行业的健康发展。",
              
              result10: "1：物流： 贸易问题和政策变化可能导致大豆物流中断，特别是跨国大豆物流链，可能提高风险" + String( Math.round(Math.random()*20) ) +" %",
              
              result11: "2:商贸：贸易问题和政策的不确定性可能对大豆商贸关系产生不利影响，导致市场波动和合同风险。",
              
              result12: "3：市场准入：政府政策和国际协议可能影响大豆产品进入不同国家市场的难易程度，进而影响大豆出口商的利益。",
                
            })

            

            // temp_graph.links.push(
            //     {
            //         'id': '51',
            //         'source': '51',
            //         'target': '43',
            //         'lineStyle': {
            //             'normal': {}
            //         },
            //         'name': '指导',
            //         'value': 1
            //     }, 
            //     {
            //         'id': '52',
            //         'source': '52',
            //         'target': '43',
            //         'lineStyle': {
            //             'normal': {}
            //         },
            //         'name': '指导',
            //         'value': 1
            //     }, 
            //     {
            //         'id': '53',
            //         'source': '53',
            //         'target': '43',
            //         'lineStyle': {
            //             'normal': {}
            //         },
            //         'name': '指导',
            //         'value': 1
            //     },  {
            //         'id': '54',
            //         'source': '51',
            //         'target': '36',
            //         'lineStyle': {
            //             'normal': {}
            //         },
            //         'name': '指导',
            //         'value': 1
            //     },  {
            //         'id': '55',
            //         'source': '52',
            //         'target': '42',
            //         'lineStyle': {
            //             'normal': {}
            //         },
            //         'name': '指导',
            //         'value': 1
            //     },  {
            //         'id': '56',
            //         'source': '53',
            //         'target': '36',
            //         'lineStyle': {
            //             'normal': {}
            //         },
            //         'name': '指导',
            //         'value': 1
            //     }, 
            // )



            temp_graph.nodes[3].category=0
            temp_graph.nodes[4].category=1
            temp_graph.nodes[5].category=1

        }
        else if(value[0]=='税收优惠类'){

            // _this.setData({
            //     result1: "1：对供应链相关节点减少税收" + String( Math.round(Math.random()*20) ) +" %   ",
            //     result2: "2：有利于企业经营",
            //     result3: "",
            //     result4: "1：增加地方政府财政支出"+ String( Math.round(Math.random()*20) ) +" %",
            //     result5: "",
            //     result6: "",
            //     result7: "1：对次生节点有影响，有利于经营",
            //     result8: "",
            //     result9: "",
            //     result10: "1：加剧市场竞争"+ String( Math.round(Math.random()*20) ) +" %",
            //     result11: "",
            //     result12: "",

            // })
            _this.setData({
              result1: "1：供应方面： 政府出台政策鼓励大豆产业和可持续发展，可能会提高供应链的技术水平和质量标准。这有助于降低供应链的质量风险" + String( Math.round(Math.random()*20) ) +" %",

              result2: "2：库存方面： 政府的大豆产业政策可能有助于平衡市场需求，减少外部不稳定影响。",
              
              result3: "3：价格方面：政府政策鼓励大豆种植，这可能降低种植成本，有助于稳定价格。",
              
              result4: "1：供应方面：贸易争端和政策变化可能导致大豆供应链的不稳定性，影响供应的可靠性。" + String( Math.round(Math.random()*20) ) +" %",
              
              result5: "2：库存方面： 市场波动和需求不确定性可能导致大豆库存风险。政策的变化可能对库存管理产生不利影响。",
              
              result6: "3：价格方面：贸易问题和政策变化可能导致大豆价格波动，尤其是对于进口大豆，这可能影响国内市场的价格。",
              
              result7: "1：物流：中国政府支持基础设施建设和国际贸易，可能改善大豆物流效率。政府政策可能有助于提高大豆运输的可靠性。",
              
              result8: "2:商贸： 政府出台政策以促进大豆产品消费，可能提高市场销售，有利于大豆商贸。贸易协定和政策的稳定性可能促进大豆的国际贸易。",
              
              result9: "3：政策环境：政府在农业补贴、土地使用等方面的支持可以增强大豆生产者的积极性，从而推动整个大豆行业的健康发展。",
              
              result10: "1：物流： 贸易问题和政策变化可能导致大豆物流中断，特别是跨国大豆物流链，可能提高风险" + String( Math.round(Math.random()*20) ) +" %",
              
              result11: "2:商贸：贸易问题和政策的不确定性可能对大豆商贸关系产生不利影响，导致市场波动和合同风险。",
              
              result12: "3：市场准入：政府政策和国际协议可能影响大豆产品进入不同国家市场的难易程度，进而影响大豆出口商的利益。",

            })

            //对图和节点操作
           
        temp_graph.nodes[3].category=0
        temp_graph.nodes[4].category=1
        temp_graph.nodes[5].category=1
        temp_graph.nodes[6].category=1
        temp_graph.nodes[7].category=1
           
            
        }
        else if(value[0]=='疏解政策类'){

            _this.setData({
                result1: "1：对供应链相关节点减少税收" + String( Math.round(Math.random()*20) ) +" %   ",
                result2: "2：有利于企业经营",
                result3: "",
                result4: "1：增加地方政府财政支出"+ String( Math.round(Math.random()*20) ) +" %",
                result5: "",
                result6: "",
                result7: "1：对次生节点有影响，有利于经营",
                result8: "",
                result9: "",
                result10: "1：加剧市场竞争"+ String( Math.round(Math.random()*20) ) +" %",
                result11: "",
                result12: "",

            })

            temp_graph.nodes[3].category=1
            temp_graph.nodes[4].category=1
            // temp_graph.nodes[5].category=1
            // temp_graph.nodes[6].category=1

        }
        


        // 从服务器获取图
        // var _this = this;
        // wx.request({
        // url: 'http://localhost:5000/api/risk/getBlockAge/?companyId=43' ,
        // header: {
        //     'content-type': 'application/json' // 默认值
        // },
        // success(res) {
        //     console.log("getRiskData的res",res);
        //     const graph = res.data;
        //     options.series[0].data = graph.nodes;
        //     options.series[0].links = graph.links;
        //     setTimeout(function () {
        //         chart2.setOption(options);
        //         console.log("zheliii")
        //     }), 5000;

        //     console.log("optionn",options)
        // }
        // });


        options.series[0].data = temp_graph.nodes;
        options.series[0].links = temp_graph.links;
        console.log("nodes and link",temp_graph.nodes,temp_graph.links)
        console.log("nodes and link,g_graph",g_graph.nodes,g_graph.links)

        //画图
        setTimeout(function () {
            chart2.setOption(options);
          }), 5000;

                
            }
        }) 




        // Toast({
        //     type: 'loading',
        //     message: '自动计算政策收益中...请稍后……',
        //     duration: 2000,
        //     onClose: () => {
        //         Toast({
        //             type: 'success',
        //             message: '已计算出单个政策正面和负面收益！',
        //             duration: 2000,
        //           });  

        //           _this.setData({
        //             tab0Value4: value[0],
        //             tab0Value5: value[1],
        //             tab0Value6: value[2],
        //             show2: false,
        //             tableShow: true,

        //             xiaoguo0:Math.round(Math.random()*100),
        //             xiaoguo1:Math.round(Math.random()*100),

        //           });

        //     }
        //   });


    },




    // 多个施策选择之后
    onConfirm3(event) {
        //index判断第几个
        console.log("ondetail", event.detail);


        var _this = this;
        const {
            picker,
            value,
            index
        } = event.detail;

        //选了第一个政策
       if(_this.data.ispolicy1==true){
        
           //重置元素
        _this.setData({
            'tab0Value[0]': value[0],
            'tab0Value[1]': value[1],
            'tab0Value[2]': value[2],
            show3: false,
            tableShow: true,
            g_hiddenn:false,
        })

       }
        //选了第2个政策
       else if(_this.data.ispolicy2==true){
        
           //重置元素
        _this.setData({
            'tab0Value[3]': value[0],
            'tab0Value[4]': value[1],
            'tab0Value[5]': value[2],
            show3: false,
            tableShow: true,
            g_hiddenn:false,
        })

       } 
       //选了第3个政策  还要改变图
       else if(_this.data.ispolicy3==true){
        
           //重置元素
        _this.setData({
            'tab0Value[6]': value[0],
            'tab0Value[7]': value[1],
            'tab0Value[8]': value[2],
            show3: false,
            tableShow: true,
            g_hiddenn:false,
        })
       }



    //    if(_this.ispolicy3==true){
    //         options.series[0].data = temp_graph.nodes;
    //         options.series[0].links = temp_graph.links;
    //         console.log("optionn",options)
    //         setTimeout(function () {
    //             chart2.setOption(options);
    //         }), 5000;
    //    }
    },


     //输出文档结果，报告
     printdoc(){
        wx.downloadFile({
            url: 'https://example.com/file',  //文件的URL
            success: function (res) {
              wx.saveFile({  //保存
                tempFilePath: res.tempFilePath,  //保存文件地址
                success: function (res) {  //成功后的回调函数
                  console.log(res.savedFilePath)
                }
              })
            }
          })
    },

    //输出文档结果，报告
    shangchuandoc(){
      
      var _this = this;
      console.log("222");
      wx.chooseMessageFile({
          count: 1,
          type: 'file',
          success(res) {
              var tempFilePaths = res.tempFiles[0].path;
              var tempFileName = res.tempFiles[0].name;
              console.log(tempFilePaths);
              console.log(tempFileName);
              console.log('选择', res);
  
              wx.uploadFile({
                  url: 'http://127.0.0.1/upload', // 您的服务器地址
                  filePath: tempFilePaths, // 使用正确的文件路径
                  name: 'file',
                  formData: {
                      'user': 'test'
                  },
                  success(uploadRes) { // 修改参数名为uploadRes以避免与外部res冲突
                      console.log('上传成功:', uploadRes.data);
                      try {
                          // 尝试解析服务器返回的JSON数据
                          const data = JSON.parse(uploadRes.data);
  
                          if (data.status === 'success') {
                              console.log('Server message:', data.message);
                              console.log('File content from server:', data.content);
  
                              // 更新页面显示等操作
                              _this.setData({ // 使用_this而不是that
                                  reason1: data.content
                              });
                          } else {
                              console.error('Error:', data.message);
                          }
                      } catch (e) {
                          console.error('Failed to parse server response:', e);
                      }
  
                      wx.showToast({
                          icon: "success", // 修改为'success'图标
                          title: '上传成功',
                          duration: 2500
                      });
                  },
                });
              upload = 1;

              wx.showLoading({
                title: '请稍候...',
                mask: true // 显示透明蒙层，防止触摸穿透
              });
          
              // 设置定时器，假设我们需要等待3秒
              setTimeout(() => {
                // 隐藏加载提示框
                wx.hideLoading();
          
                // 这里执行你的任务
                console.log('延时任务执行了');

                

                let rv = false
                let arr = [
                    {
                        title: '供应安全指数',
                        value: 66
                    },{
                        title: '库存安全度',
                        value: 55
                    },
                    {
                        title: '价格安全度',
                        value: 38
                    },
                    {
                        title: '物流安全度',
                        value: 73
                    },
                    {
                        title: '商贸安全度',
                        value: 65
                    },

                ]
                
                _this.setData({
                    risk: 66,
                    safetyIndex: arr,
                    risk_level: '2',
                    riskVisible: rv
                   
                })
          

              }, 2500);



            }




          })
      },


     //多个政策模拟结果
    monipo(){
        wx.showLoading({
            title: '请稍候...',
            mask: true // 显示透明蒙层，防止触摸穿透
          });
      
          // 设置定时器，假设我们需要等待3秒
          setTimeout(() => {
            // 隐藏加载提示框
            wx.hideLoading();
      
            // 这里执行你的任务
            console.log('延时任务执行了');
            Toast({
                type: 'loading',
                message: '计算多个政策相互影响中...请稍后……',
                duration: 2000,
                onClose: () => {
                    Toast({
                        type: 'success',
                        message: '已计算出组合政策正面和负面收益！',
                        duration: 2000,
                      });  
    
    
                    //文字效果
            
    
            if(this.data.tab2MethodValue4==1){
                this.setData({
                    result1: "1：库存：完善芯片库存数据体系,芯片数据信息整合提升，库存数据管理指标提升" + String( Math.round(Math.random()*20) ) +" %   ",
                    result2: "2：价格：芯片供应增多，价格下降",
                    result3: "3: 物流， 降低半导体公司的物流运输成本"+ String( Math.round(Math.random()*20) ) +" %   " ,
                    result4: "1：增加地方政府财政支出"+ String( Math.round(Math.random()*20) ) +" %",
                    result5: "2:增加企业竞争风险"+ String( Math.round(Math.random()*20) ) +" %",
                    result6: "3：增加金融风险"+ String( Math.round(Math.random()*30) ) +" %",
                    result7: "1：商贸：降低对美国芯片进口的依赖，降低商贸风险",
                    result8: "2：对供应链核心企业上下游企业贷款增加"+ String( Math.round(Math.random()*20) ) +" %",
                    result9: "",
                    result10: "1：加剧市场竞争"+ String( Math.round(Math.random()*20) ) +" %",
                    result11: "2：上下游原材料供给不足，生产芯片的材料短缺"+ String( Math.round(Math.random()*20) ) +" %",
                    result12: "",
                    fangzhenEntities:[[1,'直接正效果','续航里程在300公里以下的车型将不再享受补贴，续航里程在300-400公里之间的车型补贴标准下隆至9100元，补贴减少3900元而续航里程在400公里以上的车型补贴标准下降至1.26万元，补贴减少5400元。'],
                       [2,'直接正效果','进一步促进二手车便利交易，推动汽车消费。具体措施包括加强二手车流通管理、健全二手车交易规范、优化二手车交易税收政策等'],
                       [3,'直接正效果','加快充电基础设施建设、扩大新能源汽车市场、提高新能源汽车产业集中度']],
        
                })
                
            }
            else{
                this.setData({
                  result1: "1：供应方面： 政府出台政策鼓励大豆产业和可持续发展，可能会提高供应链的技术水平和质量标准。这有助于降低供应链的质量风险" + String( Math.round(Math.random()*20) ) +" %",

                  result2: "2：库存方面： 政府的大豆产业政策可能有助于平衡市场需求，减少外部不稳定影响。",
                  
                  result3: "3：价格方面：政府政策鼓励大豆种植，这可能降低种植成本，有助于稳定价格。",
                  
                  result4: "1：供应方面：贸易争端和政策变化可能导致大豆供应链的不稳定性，影响供应的可靠性。" + String( Math.round(Math.random()*20) ) +" %",
                  
                  result5: "2：库存方面： 市场波动和需求不确定性可能导致大豆库存风险。政策的变化可能对库存管理产生不利影响。",
                  
                  result6: "3：价格方面：贸易问题和政策变化可能导致大豆价格波动，尤其是对于进口大豆，这可能影响国内市场的价格。",
                  
                  result7: "1：物流：中国政府支持基础设施建设和国际贸易，可能改善大豆物流效率。政府政策可能有助于提高大豆运输的可靠性。",
                  
                  result8: "2:商贸： 政府出台政策以促进大豆产品消费，可能提高市场销售，有利于大豆商贸。贸易协定和政策的稳定性可能促进大豆的国际贸易。",
                  
                  result9: "3：政策环境：政府在农业补贴、土地使用等方面的支持可以增强大豆生产者的积极性，从而推动整个大豆行业的健康发展。",
                  
                  result10: "1：物流： 贸易问题和政策变化可能导致大豆物流中断，特别是跨国大豆物流链，可能提高风险" + String( Math.round(Math.random()*20) ) +" %",
                  
                  result11: "2:商贸：贸易问题和政策的不确定性可能对大豆商贸关系产生不利影响，导致市场波动和合同风险。",
                  
                  result12: "3：市场准入：政府政策和国际协议可能影响大豆产品进入不同国家市场的难易程度，进而影响大豆出口商的利益。",
    
                
                    fangzhenEntities:[[1,'直接正效果','续航里程在300公里以下的车型将不再享受补贴，续航里程在300-400公里之间的车型补贴标准下隆至9100元，补贴减少3900元而续航里程在400公里以上的车型补贴标准下降至1.26万元，补贴减少5400元。'],
                       [2,'直接正效果','进一步促进二手车便利交易，推动汽车消费。具体措施包括加强二手车流通管理、健全二手车交易规范、优化二手车交易税收政策等'],
                       [3,'直接正效果','加快充电基础设施建设、扩大新能源汽车市场、提高新能源汽车产业集中度']],
        
                })
            }
    
            
    
    
    
    
    
            var temp_graph = {
                'nodes': [
                    
                     {
                        'id': '52',
                        'category': 4,
                        'risk': 41,
                        'name': '主管部门',
                        'relation': '直接相关',
                        'symbolSize': 80,
                        'label': {
                            'normal': {
                                'show': true
                            }
                        },
                        'draggable': true
                     },{
                        'id': '53',
                        'category': 5,
                        'risk': 41,
                        'name': '执行部门',
                        'relation': '直接相关',
                        'symbolSize': 80,
                        'label': {
                            'normal': {
                                'show': true
                            },
                        'draggable': true
                     }}, 
                    {
                    'id': '43',
                    'category': 0,
                    'risk': 74,
                    'name': '上汽集团',
                    'relation': '主体节点',
                    'label': {
                        'normal': {
                            'show': true
                        }
                    },
                    'fixed': true,
                    'x': 200,
                    'y': 300,
                    'symbolSize': 70
                }, {
                    'id': '44',
                    'category': 1,
                    'risk': 41,
                    'name': '武汉钢铁',
                    'relation': '直接相关',
                    'symbolSize': 50,
                    'label': {
                        'normal': {
                            'show': true
                        }
                    },
                    'draggable': true
                }, {
                    'id': '36',
                    'category': 1,
                    'risk': 51,
                    'name': '吉利控股',
                    'relation': '直接相关',
                    'symbolSize': 50,
                    'label': {
                        'normal': {
                            'show': true
                        }
                    },
                    'draggable': true
                }, {
                    'id': '42',
                    'category': 2,
                    'risk': 60,
                    'name': '博世汽车部件',
                    'relation': '直接相关',
                    'symbolSize': 50,
                    'label': {
                        'normal': {
                            'show': true
                        }
                    },
                    'draggable': true
                }, {
                    'id': '46',
                    'category': 1,
                    'risk': 23,
                    'name': '中远国际货运代理',
                    'relation': '间接关联',
                    'symbolSize': 50,
                    'label': {
                        'normal': {
                            'show': true
                        }
                    },
                    'draggable': true
                }, {
                    'id': '47',
                    'category': 2,
                    'risk': 30,
                    'name': '比亚迪汽车',
                    'relation': '间接关联',
                    'symbolSize': 50,
                    'label': {
                        'normal': {
                            'show': true
                        }
                    },
                    'draggable': true
                }, {
                    'id': '39',
                    'category': 2,
                    'risk': 29,
                    'name': '北汽集团',
                    'relation': '间接关联',
                    'symbolSize': 50,
                    'label': {
                        'normal': {
                            'show': true
                        }
                    },
                    'draggable': true
                }, {
                    'id': '37',
                    'category': 2,
                    'risk': 67,
                    'name': '三一国际',
                    'relation': '间接关联',
                    'symbolSize': 50,
                    'label': {
                        'normal': {
                            'show': true
                        }
                    },
                    'draggable': true
                }, {
                    'id': '38',
                    'category': 2,
                    'risk': 32,
                    'name': '上海汽车制造',
                    'relation': '间接关联',
                    'symbolSize': 50,
                    'label': {
                        'normal': {
                            'show': true
                        }
                    },
                    'draggable': true
                }, {
                    'id': '60',
                    'category': 2,
                    'risk': 32,
                    'name': '宁波联塑集团',
                    'relation': '间接关联',
                    'symbolSize': 50,
                    'label': {
                        'normal': {
                            'show': true
                        }
                    },
                    'draggable': true
                }, {
                    'id': '61',
                    'category': 2,
                    'risk': 32,
                    'name': '宝钢集团',
                    'relation': '间接关联',
                    'symbolSize': 50,
                    'label': {
                        'normal': {
                            'show': true
                        }
                    },
                    'draggable': true
                }, {
                    'id': '62',
                    'category': 2,
                    'risk': 32,
                    'name': '沃尔沃汽车零部件',
                    'relation': '间接关联',
                    'symbolSize': 50,
                    'label': {
                        'normal': {
                            'show': true
                        }
                    },
                    'draggable': true
                }, {
                    'id': '63',
                    'category': 2,
                    'risk': 32,
                    'name': '圆通汽车物流',
                    'relation': '间接关联',
                    'symbolSize': 50,
                    'label': {
                        'normal': {
                            'show': true
                        }
                    },
                    'draggable': true
                }
            ],
                'links': [
                    // {
                    //             'id': '51',
                    //             'source': '51',
                    //             'target': '43',
                    //             'lineStyle': {
                    //                 'normal': {}
                    //             },
                    //             'name': '指导',
                    //             'value': 1
                    //         }, 
                            {
                                'id': '52',
                                'source': '52',
                                'target': '43',
                                'lineStyle': {
                                    'normal': {}
                                },
                                'name': '指导',
                                'value': 1
                            }, 
                            {
                                'id': '53',
                                'source': '53',
                                'target': '43',
                                'lineStyle': {
                                    'normal': {}
                                },
                                'name': '指导',
                                'value': 1
                            }, 
                            //  {
                            //     'id': '54',
                            //     'source': '51',
                            //     'target': '36',
                            //     'lineStyle': {
                            //         'normal': {}
                            //     },
                            //     'name': '指导',
                            //     'value': 1
                            // },  
                            {
                                'id': '55',
                                'source': '52',
                                'target': '42',
                                'lineStyle': {
                                    'normal': {}
                                },
                                'name': '指导',
                                'value': 1
                            },  {
                                'id': '56',
                                'source': '53',
                                'target': '36',
                                'lineStyle': {
                                    'normal': {}
                                },
                                'name': '指导',
                                'value': 1
                            }, 
                    
                    {
                    'id': '44',
                    'source': '43',
                    'target': '44',
                    'lineStyle': {
                        'normal': {}
                    },
                    'name': '合作',
                    'value': 1
                }, {
                    'id': '36',
                    'source': '43',
                    'target': '36',
                    'lineStyle': {
                        'normal': {}
                    },
                    'name': '合作',
                    'value': 1
                }, {
                    'id': '42',
                    'source': '43',
                    'target': '42',
                    'lineStyle': {
                        'normal': {}
                    },
                    'name': '合作',
                    'value': 1
                }, {
                    'id': '46',
                    'source': '36',
                    'target': '46',
                    'lineStyle': {
                        'normal': {}
                    },
                    'name': '合作',
                    'value': 1
                }, {
                    'id': '47',
                    'source': '36',
                    'target': '47',
                    'lineStyle': {
                        'normal': {}
                    },
                    'name': '合作',
                    'value': 1
                }, {
                    'id': '39',
                    'source': '36',
                    'target': '39',
                    'lineStyle': {
                        'normal': {}
                    },
                    'name': '合作',
                    'value': 1
                }, {
                    'id': '37',
                    'source': '36',
                    'target': '37',
                    'lineStyle': {
                        'normal': {}
                    },
                    'name': '合作',
                    'value': 1
                }, {
                    'id': '38',
                    'source': '36',
                    'target': '38',
                    'lineStyle': {
                        'normal': {}
                    },
                    'name': '合作',
                    'value': 1
                }, {
                    'id': '60',
                    'source': '36',
                    'target': '60',
                    'lineStyle': {
                        'normal': {}
                    },
                    'name': '合作',
                    'value': 1
                }, {
                    'id': '61',
                    'source': '47',
                    'target': '61',
                    'lineStyle': {
                        'normal': {}
                    },
                    'name': '合作',
                    'value': 1
                }, {
                    'id': '62',
                    'source': '46',
                    'target': '62',
                    'lineStyle': {
                        'normal': {}
                    },
                    'name': '合作',
                    'value': 1
                }, {
                    'id': '63',
                    'source': '36',
                    'target': '63',
                    'lineStyle': {
                        'normal': {}
                    },
                    'name': '合作',
                    'value': 1
                }
            ]
            }
    
            var temp_graph2 = {
                'nodes': [
                    
                     {
                        'id': '52',
                        'category': 4,
                        'risk': 41,
                        'name': '主管部门',
                        'relation': '直接相关',
                        'symbolSize': 80,
                        'label': {
                            'normal': {
                                'show': true
                            }
                        },
                        'draggable': true
                     },{
                        'id': '53',
                        'category': 5,
                        'risk': 41,
                        'name': '执行部门',
                        'relation': '直接相关',
                        'symbolSize': 80,
                        'label': {
                            'normal': {
                                'show': true
                            },
                        'draggable': true
                     }}, 
                    {
                    'id': '43',
                    'category': 0,
                    'risk': 74,
                    'name': '紫光国微',
                    'relation': '主体节点',
                    'label': {
                        'normal': {
                            'show': true
                        }
                    },
                    'fixed': true,
                    'x': 200,
                    'y': 300,
                    'symbolSize': 70
                }, {
                    'id': '44',
                    'category': 1,
                    'risk': 41,
                    'name': '中芯国际',
                    'relation': '直接相关',
                    'symbolSize': 50,
                    'label': {
                        'normal': {
                            'show': true
                        }
                    },
                    'draggable': true
                }, {
                    'id': '36',
                    'category': 1,
                    'risk': 51,
                    'name': '长电科技',
                    'relation': '直接相关',
                    'symbolSize': 50,
                    'label': {
                        'normal': {
                            'show': true
                        }
                    },
                    'draggable': true
                }, {
                    'id': '42',
                    'category': 2,
                    'risk': 60,
                    'name': '韦尔股份',
                    'relation': '直接相关',
                    'symbolSize': 50,
                    'label': {
                        'normal': {
                            'show': true
                        }
                    },
                    'draggable': true
                }, {
                    'id': '46',
                    'category': 1,
                    'risk': 23,
                    'name': '通富微电',
                    'relation': '间接关联',
                    'symbolSize': 50,
                    'label': {
                        'normal': {
                            'show': true
                        }
                    },
                    'draggable': true
                }, {
                    'id': '47',
                    'category': 2,
                    'risk': 30,
                    'name': '北方华创',
                    'relation': '间接关联',
                    'symbolSize': 50,
                    'label': {
                        'normal': {
                            'show': true
                        }
                    },
                    'draggable': true
                }, {
                    'id': '39',
                    'category': 2,
                    'risk': 29,
                    'name': '华天科技',
                    'relation': '间接关联',
                    'symbolSize': 50,
                    'label': {
                        'normal': {
                            'show': true
                        }
                    },
                    'draggable': true
                }, {
                    'id': '37',
                    'category': 2,
                    'risk': 67,
                    'name': '华润微',
                    'relation': '间接关联',
                    'symbolSize': 50,
                    'label': {
                        'normal': {
                            'show': true
                        }
                    },
                    'draggable': true
                }, {
                    'id': '38',
                    'category': 2,
                    'risk': 32,
                    'name': '兆易创新',
                    'relation': '间接关联',
                    'symbolSize': 50,
                    'label': {
                        'normal': {
                            'show': true
                        }
                    },
                    'draggable': true
                }, {
                    'id': '60',
                    'category': 2,
                    'risk': 32,
                    'name': '江波龙',
                    'relation': '间接关联',
                    'symbolSize': 50,
                    'label': {
                        'normal': {
                            'show': true
                        }
                    },
                    'draggable': true
                }, {
                    'id': '61',
                    'category': 2,
                    'risk': 32,
                    'name': '紫光A',
                    'relation': '间接关联',
                    'symbolSize': 50,
                    'label': {
                        'normal': {
                            'show': true
                        }
                    },
                    'draggable': true
                }, {
                    'id': '62',
                    'category': 2,
                    'risk': 32,
                    'name': '格科微',
                    'relation': '间接关联',
                    'symbolSize': 50,
                    'label': {
                        'normal': {
                            'show': true
                        }
                    },
                    'draggable': true
                }, {
                    'id': '63',
                    'category': 2,
                    'risk': 32,
                    'name': '晶晨股份',
                    'relation': '间接关联',
                    'symbolSize': 50,
                    'label': {
                        'normal': {
                            'show': true
                        }
                    },
                    'draggable': true
                }
            ],
            //     'links': [
            //         // {
            //         //             'id': '51',
            //         //             'source': '51',
            //         //             'target': '43',
            //         //             'lineStyle': {
            //         //                 'normal': {}
            //         //             },
            //         //             'name': '指导',
            //         //             'value': 1
            //         //         }, 
            //                 {
            //                     'id': '52',
            //                     'source': '52',
            //                     'target': '43',
            //                     'lineStyle': {
            //                         'normal': {}
            //                     },
            //                     'name': '指导',
            //                     'value': 1
            //                 }, 
            //                 {
            //                     'id': '53',
            //                     'source': '53',
            //                     'target': '43',
            //                     'lineStyle': {
            //                         'normal': {}
            //                     },
            //                     'name': '指导',
            //                     'value': 1
            //                 }, 
            //                 //  {
            //                 //     'id': '54',
            //                 //     'source': '51',
            //                 //     'target': '36',
            //                 //     'lineStyle': {
            //                 //         'normal': {}
            //                 //     },
            //                 //     'name': '指导',
            //                 //     'value': 1
            //                 // },  
            //                 {
            //                     'id': '55',
            //                     'source': '52',
            //                     'target': '42',
            //                     'lineStyle': {
            //                         'normal': {}
            //                     },
            //                     'name': '指导',
            //                     'value': 1
            //                 },  {
            //                     'id': '56',
            //                     'source': '53',
            //                     'target': '36',
            //                     'lineStyle': {
            //                         'normal': {}
            //                     },
            //                     'name': '指导',
            //                     'value': 1
            //                 }, 
                    
            //         {
            //         'id': '44',
            //         'source': '43',
            //         'target': '44',
            //         'lineStyle': {
            //             'normal': {}
            //         },
            //         'name': '合作',
            //         'value': 1
            //     }, {
            //         'id': '36',
            //         'source': '43',
            //         'target': '36',
            //         'lineStyle': {
            //             'normal': {}
            //         },
            //         'name': '合作',
            //         'value': 1
            //     }, {
            //         'id': '42',
            //         'source': '43',
            //         'target': '42',
            //         'lineStyle': {
            //             'normal': {}
            //         },
            //         'name': '合作',
            //         'value': 1
            //     }, {
            //         'id': '46',
            //         'source': '36',
            //         'target': '46',
            //         'lineStyle': {
            //             'normal': {}
            //         },
            //         'name': '合作',
            //         'value': 1
            //     }, {
            //         'id': '47',
            //         'source': '36',
            //         'target': '47',
            //         'lineStyle': {
            //             'normal': {}
            //         },
            //         'name': '合作',
            //         'value': 1
            //     }, {
            //         'id': '39',
            //         'source': '36',
            //         'target': '39',
            //         'lineStyle': {
            //             'normal': {}
            //         },
            //         'name': '合作',
            //         'value': 1
            //     }, {
            //         'id': '37',
            //         'source': '36',
            //         'target': '37',
            //         'lineStyle': {
            //             'normal': {}
            //         },
            //         'name': '合作',
            //         'value': 1
            //     }, {
            //         'id': '38',
            //         'source': '36',
            //         'target': '38',
            //         'lineStyle': {
            //             'normal': {}
            //         },
            //         'name': '合作',
            //         'value': 1
            //     }, {
            //         'id': '60',
            //         'source': '36',
            //         'target': '60',
            //         'lineStyle': {
            //             'normal': {}
            //         },
            //         'name': '合作',
            //         'value': 1
            //     }, {
            //         'id': '61',
            //         'source': '47',
            //         'target': '61',
            //         'lineStyle': {
            //             'normal': {}
            //         },
            //         'name': '合作',
            //         'value': 1
            //     }, {
            //         'id': '62',
            //         'source': '46',
            //         'target': '62',
            //         'lineStyle': {
            //             'normal': {}
            //         },
            //         'name': '合作',
            //         'value': 1
            //     }, {
            //         'id': '63',
            //         'source': '36',
            //         'target': '63',
            //         'lineStyle': {
            //             'normal': {}
            //         },
            //         'name': '合作',
            //         'value': 1
            //     }
            // ],
            'links': [
                // {
                //             'id': '51',
                //             'source': '51',
                //             'target': '43',
                //             'lineStyle': {
                //                 'normal': {}
                //             },
                //             'name': '指导',
                //             'value': 1
                //         }, 
                        {
                            'id': '52',
                            'source': '52',
                            'target': '43',
                            'lineStyle': {
                                'normal': {}
                            },
                            'name': '指导',
                            'value': 1
                        }, 
                        {
                            'id': '53',
                            'source': '53',
                            'target': '43',
                            'lineStyle': {
                                'normal': {}
                            },
                            'name': '指导',
                            'value': 1
                        }, 
                        //  {
                        //     'id': '54',
                        //     'source': '51',
                        //     'target': '36',
                        //     'lineStyle': {
                        //         'normal': {}
                        //     },
                        //     'name': '指导',
                        //     'value': 1
                        // },  
                        {
                            'id': '55',
                            'source': '52',
                            'target': '42',
                            'lineStyle': {
                                'normal': {}
                            },
                            'name': '指导',
                            'value': 1
                        },  {
                            'id': '56',
                            'source': '53',
                            'target': '36',
                            'lineStyle': {
                                'normal': {}
                            },
                            'name': '指导',
                            'value': 1
                        }, 
                
                {
                'id': '44',
                'source': '43',
                'target': '44',
                'lineStyle': {
                    'normal': {}
                },
                'name': '合作',
                'value': 1
            }, {
                'id': '36',
                'source': '43',
                'target': '36',
                'lineStyle': {
                    'normal': {}
                },
                'name': '合作',
                'value': 1
            }, {
                'id': '42',
                'source': '43',
                'target': '42',
                'lineStyle': {
                    'normal': {}
                },
                'name': '合作',
                'value': 1
            }, {
                'id': '46',
                'source': '36',
                'target': '46',
                'lineStyle': {
                    'normal': {}
                },
                'name': '合作',
                'value': 1
            }, {
                'id': '47',
                'source': '36',
                'target': '47',
                'lineStyle': {
                    'normal': {}
                },
                'name': '合作',
                'value': 1
            }, {
                'id': '39',
                'source': '36',
                'target': '39',
                'lineStyle': {
                    'normal': {}
                },
                'name': '合作',
                'value': 1
            }, {
                'id': '37',
                'source': '43',
                'target': '37',
                'lineStyle': {
                    'normal': {}
                },
                'name': '合作',
                'value': 1
            }, {
                'id': '38',
                'source': '43',
                'target': '38',
                'lineStyle': {
                    'normal': {}
                },
                'name': '合作',
                'value': 1
            }, {
                'id': '60',
                'source': '43',
                'target': '60',
                'lineStyle': {
                    'normal': {}
                },
                'name': '合作',
                'value': 1
            }, {
                'id': '61',
                'source': '47',
                'target': '61',
                'lineStyle': {
                    'normal': {}
                },
                'name': '合作',
                'value': 1
            }, {
                'id': '62',
                'source': '46',
                'target': '62',
                'lineStyle': {
                    'normal': {}
                },
                'name': '合作',
                'value': 1
            }, {
                'id': '63',
                'source': '36',
                'target': '63',
                'lineStyle': {
                    'normal': {}
                },
                'name': '合作',
                'value': 1
            },
            {
                'id': '64',
                'source': '52',
                'target': '39',
                'lineStyle': {
                    'normal': {}
                },
                'name': '指导',
                'value': 1
            }, 
            {
                'id': '65',
                'source': '53',
                'target': '44',
                'lineStyle': {
                    'normal': {}
                },
                'name': '指导',
                'value': 1
            }, 
        ]
            }
    
            //加入部门节点
            // if(this.data.tab0Value[1]!='请选择'){
            //     temp_graph.nodes.push(
            //         {
            //             'id': '57',
            //             'category': 3,
            //             'risk': 41,
            //             'name': this.data.tab0Value[1],
            //             'relation': '直接相关',
            //             'symbolSize': 80,
            //             'label': {
            //                 'normal': {
            //                     'show': true
            //                 }
            //             },
            //             'draggable': true
            //          }
            //     )
            //     temp_graph.links.push(
            //         {
            //             'id': '57',
            //             'source': '57',
            //             'target': '43',
            //             'lineStyle': {
            //                 'normal': {}
            //             },
            //             'name': '指导',
            //             'value': 1
            //         }, 
            //     )
            //     temp_graph.nodes[6].category=1
            //     temp_graph.nodes[3].category=1
            // }
            // if(this.data.tab0Value[4]!='请选择'){
            //     temp_graph.nodes.push(
            //         {
            //             'id': '58',
            //             'category': 3,
            //             'risk': 41,
            //             'name': this.data.tab0Value[4],
            //             'relation': '直接相关',
            //             'symbolSize': 80,
            //             'label': {
            //                 'normal': {
            //                     'show': true
            //                 }
            //             },
            //             'draggable': true
            //          }
            //     )
            //     temp_graph.links.push(
            //         {
            //             'id': '58',
            //             'source': '58',
            //             'target': '43',
            //             'lineStyle': {
            //                 'normal': {}
            //             },
            //             'name': '指导',
            //             'value': 1
            //         }, 
            //     )
            //     temp_graph.nodes[3].category=0
            //     temp_graph.nodes[7].category=1
            // }
            // if(this.data.tab0Value[7]!='请选择'){
            //     temp_graph.nodes.push(
            //         {
            //             'id': '59',
            //             'category': 3,
            //             'risk': 41,
            //             'name': this.data.tab0Value[7],
            //             'relation': '直接相关',
            //             'symbolSize': 80,
            //             'label': {
            //                 'normal': {
            //                     'show': true
            //                 }
            //             },
            //             'draggable': true
            //          }
            //     )
            //     temp_graph.links.push(
            //         {
            //             'id': '59',
            //             'source': '59',
            //             'target': '43',
            //             'lineStyle': {
            //                 'normal': {}
            //             },
            //             'name': '指导',
            //             'value': 1
            //         }, 
            //     )
            // }
    
    
            if(this.data.tab2MethodValue4==0){
                options.series[0].data = temp_graph.nodes;
                options.series[0].links = temp_graph.links;
            }else if(this.data.tab2MethodValue4==1){
                options.series[0].data = temp_graph2.nodes;
                options.series[0].links = temp_graph2.links;
            }
    
    
            
    
            setTimeout(function () {
                chart2.setOption(options);
            }), 5000;
    
                     
                }
              });
      
            // 可以是跳转页面，更新数据等操作
            // wx.navigateTo({ url: '/pages/your-page/your-page' });
          }, 2000);


         

        
    },


    // // 之前的施策选择
    // onConfirm3(event) {

    //     console.log("detail", event.detail)

    //     var _this = this;
    //     const {
    //         picker,
    //         value,
    //         index
    //     } = event.detail;

    //     _this.setData({
    //         tab0Value7: value[0],
    //         tab0Value8: value[1],
    //         tab0Value9: value[2],
    //         show3: false,
    //         tableShow: true
    //     });

    // },

    // 施策选择
    // onConfirm4(event) {
    //     console.log("detail", event.detail)
    //     var _this = this;
    //     const {
    //         picker,
    //         value,
    //         index
    //     } = event.detail;




    //     Toast({
    //         type: 'loading',
    //         message: '自动计算政策收益中...请稍后……',
    //         duration: 2000,
    //         onClose: () => {
    //             Toast({
    //                 type: 'success',
    //                 message: '已计算出两个政策叠加的正面和负面收益！',
    //                 duration: 2000,
    //             });

    //             _this.setData({
    //                 tab0Value10: value[0],
    //                 tab0Value11: value[1],
    //                 tab0Value12: value[2],



    //                 show4: false,
    //                 tableShow: true
    //             });

    //         }
    //     });



    // },






    getBlockInterpretation() {
        var _this = this
        wx.request({
            url: 'http://localhost:5000/api/risk/block/interpretation',
            data: {
                chain: _this.data.tab0Value1,
                type: _this.data.tab0Value2,
                month: _this.data.tab0Value3
            },
            success(res) {
                console.log('获取解读', res['data'])
                let policy = res['data']['policy']
                let k = []
                let ka = Object.keys(policy)
                for (let i = 0; i < ka.length; ++i) {
                    k.push({
                        'category': ka[i],
                        'specific': policy[ka[i]]
                    })
                }
                _this.setData({
                    msg: k,
                    msgVisible: res['data']['msgIncluded']
                })
            }
        })
    },

    onCancel() {
        this.setData({
            show: false,
            show2: false,
            show3: false,
            show4: false,
            g_hiddenn:false,
        })
    },
    // onSwitch1Change({
    //   detail
    // }) {
    //   this.setData({
    //     value1: detail
    //   });
    //   this.getRiskValue();
    //   this.getBlockEntities();
    //   this.getCarryEntities();
    // },

    // onSwitch2Change({
    //   detail
    // }) {
    //   this.setData({
    //     value2: detail
    //   });
    //   this.getRiskValue();
    //   this.getBlockEntities();
    //   this.getCarryEntities();
    // },


    //tab2的问题概览
    onSwitch3Change({
        detail
    }) {

        wx.showLoading({
            title: '请稍候...',
            mask: true // 显示透明蒙层，防止触摸穿透
          });
      
          // 设置定时器，假设我们需要等待3秒
          setTimeout(() => {
            // 隐藏加载提示框
            wx.hideLoading();
      
            // 这里执行你的任务
            console.log('延时任务执行了');
            console.log("onSwitch3Change")
        var _this = this;
        _this.setData({
            blockEntities2Value: detail,
            blockEntityUserRemarks: []
        });
        _this.getBlockEntityDetail(detail);
        _this.getBlockage();
        _this.getUserRemarks(app.globalData.openid, _this.data.blockEntities2Value, 1);
      
            // 可以是跳转页面，更新数据等操作
            // wx.navigateTo({ url: '/pages/your-page/your-page' });
          }, 3000);

        

    },

    


    toVisible() {
        console.log("可视化堵点分析", this.data.blockEntities2Value)
        wx.navigateTo({
            url: '../graph/graph?id=' + this.data.blockEntities2Value + '&type=0'
        })
        // this.setData({
        //   loading: !this.data.loading,
        // })
        // console.log("loading: "+ this.data.loading);

        // console.log(options.series[0].data );
        // console.log(options.series[0].links )
    },

    analysisVisualization() {
        console.log("疏导结果", this.data.tab2CarryEntitiesValue)
        wx.navigateTo({
            url: '../graph/graph?id=' + this.data.tab2CarryEntitiesValue + '&type=0'
        })
        // this.setData({
        //   loading: !this.data.loading,
        // })
        // console.log("loading: "+ this.data.loading);

        // console.log(options.series[0].data );
        // console.log(options.series[0].links )
    },
    onChange(event) {
        this.setData({
            activeNames: event.detail
        });
    },

    onChangeBasic(event) {
        this.setData({
            activeBasic: event.detail
        });
    },
    analysisResultOnChange(event) {

        this.setData({
            analysisResultActiveNames: event.detail
        });
    },
    onTab(event) {
        var _this = this;
        this.setData({
            active: event.detail.name,
          });

    },
    onTab1(event) {

        this.setData({
            activeEntityType: event.detail.index,
        })

    },
    blockEntityBind(event) {
        console.log(event)
        wx.navigateTo({
            url: '../graph/graph?id=' + event.currentTarget.dataset.id + '&type=0'
        })
    },
    carryEntityBind(event) {

        wx.navigateTo({
            url: '../graph/graph?id=' + event.currentTarget.dataset.id + '&type=1'
        })
    },


    onLoad: function (option) {



      

        var _this = this;

        _this.getRiskValue();
        _this.getBlockEntities();
        _this.getCarryEntities();
        _this.getTab2Ready();
        _this.getTab3Ready();
        _this.getCalBasic();
        _this.getBlockInterpretation();
        _this.getRecords();

        //画柱状图
        _this.messureCanvas()

    },


    // //画柱状图

    // messureCanvas(){
    //     let query = wx.createSelectorQuery().in(this);
    //     // 然后逐个取出navbar和header的节点信息
    //     // 选择器的语法与jQuery语法相同
    //     query.select('#columnarCanvas').boundingClientRect();
    //     // 执行上面所指定的请求，结果会按照顺序存放于一个数组中，在callback的第一个参数中返回
    //     var that = this
    //     query.exec((res) => {
    //       // 分别取出navbar和header的高度 
    //       console.log(res)
    //       var canvasInfo = {}
    //       canvasInfo.width = res[0].width
    //       canvasInfo.height = res[0].height
    //       that.setData({
    //         canvasInfo:canvasInfo
    //       })
    //       console.log(canvasInfo)
    //       that.drawColumnar()
    //     })
    //   },

    //   drawColumnar() {
    //     const ctxColumnar = wx.createCanvasContext("columnarCanvas")
    //     var dataList = this.data.dataList
    //     var canvasInfo = this.data.canvasInfo
    //     var columnarNum = dataList.length
    //     var columnarWidth = (canvasInfo.width-30)/(2*columnarNum+1)
    //     console.log("宽度",columnarWidth)
    //     var maxColumnarHeight = canvasInfo.height - 60 - 20
    //     var maxColumnarValue = 0
    //     var totalValue= 0
    //     for (var i = 0; i < dataList.length; i++){
    //       if(dataList[i].value>maxColumnarValue){
    //         maxColumnarValue = dataList[i].value
    //       }
    //       totalValue = totalValue+dataList[i].value
    //     }
    //     for (var i = 0; i < dataList.length;i++){
    //       ctxColumnar.setFontSize(15)
    //       var percent = parseInt(dataList[i].value * 100 / totalValue) + "%"
    //       var dx = columnarWidth * (2 * i + 1)
    //       var dy = canvasInfo.height - (maxColumnarHeight * (dataList[i].value / maxColumnarValue) + 60) + 10
    //       ctxColumnar.setFillStyle('#2b2b2b')
    //       var percentWidth = ctxColumnar.measureText(percent)
    //       ctxColumnar.fillText(percent, dx+columnarWidth/2-percentWidth.width/2, dy)
    //       ctxColumnar.setFillStyle('rgb(99, 112, 210)')
    //       var valueWidth = ctxColumnar.measureText(dataList[i].value+"")
    //       ctxColumnar.fillText(dataList[i].value+"",dx+columnarWidth/2-valueWidth.width/2,dy+20)
    //       ctxColumnar.fillRect(dx, dy + 22, columnarWidth, maxColumnarHeight * (dataList[i].value / maxColumnarValue))
    //       ctxColumnar.setFillStyle('#8a8a8a')
    //       var titleWidth = ctxColumnar.measureText(dataList[i].title + "")
    //       ctxColumnar.fillText(dataList[i].title , dx+columnarWidth/2-titleWidth.width/2, canvasInfo.height-10)
    //     }
    //     ctxColumnar.draw()
    //   },




    //获取风险值
    getRiskValue() {
       
        var _this = this;
        console.log("运行到获取风险",_this.data.tab0Value1)

         if(_this.data.tab0Value1=='汽车')
         {
             console.log("这是汽车")
            var risk_name ='钢铁'
         }
         else if(_this.data.tab0Value1=='芯片'){
            var risk_name ='棉花'
         }
         else{
            var risk_name =_this.data.tab0Value1
         }
        //var risk_name = _this.data.tab0Value1;
        var risk_type = _this.data.tab0Value2;
        // wx.request({
        //     url: 'http://localhost:5000/api/risk/getRiskValue/?risk_name=' + risk_name + '&risk_type=' + risk_type,
        //     header: {
        //         'content-type': 'application/json' // 默认值
        //     },
        //     success(res) {
        //         console.log('供应', res)
        //         let rv = false
        //         let arr = [{
        //                 title: '库存安全度',
        //                 value: res.data.repertory_risk_value
        //             },
        //             {
        //                 title: '价格安全度',
        //                 value: res.data.fund_risk_value
        //             },
        //             {
        //                 title: '物流安全度',
        //                 value: res.data.logistics_risk_value
        //             },
        //             {
        //                 title: '商贸安全度',
        //                 value: res.data.commerce_risk_value
        //             },

        //         ]
        //         if ('security_index' in res.data) {
        //             rv = true
        //             arr.splice(0, 0, {
        //                 title: '供应安全指数',
        //                 value: res.data.security_index
        //             })
        //         }
        //         _this.setData({
        //             risk: res.data.risk_value,
        //             safetyIndex: arr,
        //             risk_level: 'risk_level' in res.data ? res.data.risk_level : '',
        //             riskVisible: rv
        //             // supplySafetyIndex: 'supply_safety_index' in res.data ? res.data.supply_safety_index : 0,
        //             // riskWarning: 'risk_warning' in res.data ? res.data.risk_warning : '',
        //         })
        //     }
        // })

        // let rv = false
        // let arr = [
        //     {
        //         title: '供应安全指数',
        //         value: 62
        //     },{
        //         title: '库存安全度',
        //         value: 55
        //     },
        //     {
        //         title: '价格安全度',
        //         value: 38
        //     },
        //     {
        //         title: '物流安全度',
        //         value: 73
        //     },
        //     {
        //         title: '商贸安全度',
        //         value: 65
        //     },

        // ]
        
        // _this.setData({
        //     risk: 66,
        //     safetyIndex: arr,
        //     risk_level: '2',
        //     riskVisible: rv
        //     // supplySafetyIndex: 'supply_safety_index' in res.data ? res.data.supply_safety_index : 0,
        //     // riskWarning: 'risk_warning' in res.data ? res.data.risk_warning : '',
        // })
    },
    //初始化tab2堵点分析
    getTab2Ready() {
        var _this = this;
        _this.getAllBlockEntities();
        _this.getBlockEntityDetail();
        _this.getBlockage();


    },
    //初始化tab3施策及疏点分析
    getTab3Ready() {
        var _this = this;
        _this.getAllCarryEntities();
        _this.getPolicies();
        // _this.getMethods();

        _this.getPolicies2();
        _this.getPolicies3();

    },
    //初始化政策工具箱数据
    getPolicies() {

        // var _this = this;
        // wx.request({
        //   url: 'http://localhost:5000/api/risk/getPolicies/',
        //   header: {
        //     'content-type': 'application/json' // 默认值
        //   },
        //   success(res) {

        //     var tempArry = [];
        //     // for (var i = 0; i < res.data.policies.length; i++) {
        //     //   var tempIndex = {
        //     //     text: '1',
        //     //     value: 1
        //     //   }
        //     //   var te = res.data.policies[i][1];
        //     //   var val = res.data.policies[i][0];
        //     //   console.log("te val",te,val)
        //     //   tempIndex.text = te;
        //     //   tempIndex.value = val;
        //     //   tempArry.push(tempIndex);
        //     // }
        //     tempArry.push(
        //       {
        //         text: "普惠金融类",
        //         value: 0
        //       }

        //     );



        //     _this.setData({
        //       tab2Policy: tempArry,
        //       tab2PolicyValue: tempArry[0].value
        //     })

        //   }

        // });

        var tempArry = [];

        tempArry.push({
            text: "财政部及工业和信息化部、科技部",
            value: 0
        });

        this.setData({
            tab2Policy: tempArry,
            tab2PolicyValue: tempArry[0].value
        })


        var tempArry2 = []
        tempArry2.push({
            text: "财政补贴政策",
            value: 0
        })
        tempArry2.push({
            text: "政策保险",
            value: 1
        })
        tempArry2.push({
            text: "政府补贴",
            value: 2
        })
        this.setData({
            tab2Method: tempArry2,
            tab2MethodValue: tempArry2[0].value
        })


    },

    getPolicies2() {

        var tempArry = [];

        tempArry.push({
            text: "生态环境部和商务部",
            value: 0
        });

        this.setData({
            tab2Policy2: tempArry,
            tab2PolicyValue2: tempArry[0].value
        })


        var tempArry2 = []
        tempArry2.push({
            text: "促进二手车便利交易",
            value: 0
        })
        tempArry2.push({
            text: "税收优惠政策",
            value: 1
        })
        tempArry2.push({
            text: "税收增加",
            value: 2
        })
        this.setData({
            tab2Method2: tempArry2,
            tab2MethodValue2: tempArry2[0].value
        })
    },


    getPolicies3() {

        var tempArry = [];

        tempArry.push({
            text: "财政部、税务总局和工业信息化部",
            value: 0
        });

        this.setData({
            tab2Policy3: tempArry,
            tab2PolicyValue3: tempArry[0].value
        })


        var tempArry2 = []
        tempArry2.push({
            text: "新能源汽车购置税",
            value: 0
        })
        tempArry2.push({
            text: "疏解库存",
            value: 1
        })
        tempArry2.push({
            text: "疏解物流",
            value: 2
        })
        this.setData({
            tab2Method3: tempArry2,
            tab2MethodValue3: tempArry2[0].value
        })
    },

   


    //初始化疏解方法
    //   getMethods() {

    //     // console.log("thismethod2",this.data.tab2Method)


    //     var _this = this;
    //     console.log("shujie",_this.data.tab2PolicyValue)


    //     var tempArry = [];
    //     if(_this.data.tab2PolicyValue==0){
    //         tempArry = []
    //         tempArry.push({
    //             text: "政策A",
    //         value: 0
    //         })
    //         tempArry.push({
    //                 text: "政策B",
    //             value: 1
    //         })
    //         tempArry.push({
    //             text: "政策C",
    //         value: 2
    //     })
    //     }

    //     else if(_this.data.tab2PolicyValue==1){
    //         tempArry = []
    //         tempArry.push({
    //             text: "政策",
    //         value: 0
    //         })
    //         tempArry.push({
    //                 text: "发改委金融政策",
    //             value: 1
    //         })
    //         tempArry.push({
    //             text: "发改委其它政策",
    //         value: 2
    //     })
    //     }

    //     else if(_this.data.tab2PolicyValue==2){
    //         tempArry = []
    //         tempArry.push({
    //             text: "疏解政策类-调节利率",
    //         value: 0
    //         })
    //         tempArry.push({
    //                 text: "疏解政策类-放宽贷款",
    //             value: 1
    //         })
    //         tempArry.push({
    //             text: "疏解政策类-加息",
    //         value: 2
    //         })
    //         tempArry.push({
    //             text: "疏解政策类-降息",
    //         value: 3
    //         })
    //     }
    //     else if(_this.data.tab2PolicyValue==3){
    //         tempArry = []
    //         tempArry.push({
    //             text: "补贴",
    //         value: 0
    //         })
    //         tempArry.push({
    //                 text: "研发",
    //             value: 1
    //         })
    //         tempArry.push({
    //             text: "免税",
    //         value: 2
    //         })
    //     }




    //     tempArry.push({
    //       text: "其他",
    //       value: 3
    //     });



    //     _this.setData({
    //       tab2Method: tempArry,
    //       tab2MethodValue: tempArry[0].value
    //     })

    //     console.log("thismethod",_this.data.tab2Method)



    //     wx.request({
    //       url: 'http://localhost:5000/api/risk/getMethodsByPolicy/?id=' + _this.data.tab2PolicyValue,
    //       header: {
    //         'content-type': 'application/json' // 默认值
    //       },
    //       success(res) {

    //         var tempArry = [];
    //         // for (var i = 0; i < res.data.methods.length; i++) {
    //         //   var tempIndex = {
    //         //     text: '1',
    //         //     value: 1
    //         //   }
    //         //   var te = res.data.methods[i].name;
    //         //   var val = res.data.methods[i].id;
    //         //   tempIndex.text = te;
    //         //   tempIndex.value = val;
    //         //   tempArry.push(tempIndex);
    //         // }

    //         if(_this.data.tab2PolicyValue==0){
    //             tempArry = []
    //             tempArry.push({
    //                 text: "政策A",
    //             value: 0
    //             })
    //             tempArry.push({
    //                     text: "政策B",
    //                 value: 1
    //             })
    //             tempArry.push({
    //                 text: "政策C",
    //             value: 2
    //         })
    //         }

    //         else if(_this.data.tab2PolicyValue==1){
    //             tempArry = []
    //             tempArry.push({
    //                 text: "政策",
    //             value: 0
    //             })
    //             tempArry.push({
    //                     text: "发改委金融政策",
    //                 value: 1
    //             })
    //             tempArry.push({
    //                 text: "发改委其它政策",
    //             value: 2
    //         })
    //         }

    //         else if(_this.data.tab2PolicyValue==2){
    //             tempArry = []
    //             tempArry.push({
    //                 text: "疏解政策类-调节利率",
    //             value: 0
    //             })
    //             tempArry.push({
    //                     text: "疏解政策类-放宽贷款",
    //                 value: 1
    //             })
    //             tempArry.push({
    //                 text: "疏解政策类-加息",
    //             value: 2
    //             })
    //             tempArry.push({
    //                 text: "疏解政策类-降息",
    //             value: 2
    //             })
    //         }


    //         console.log("temp",tempArry)

    //         tempArry.push({
    //           text: "其他",
    //           value: 3
    //         });



    //         _this.setData({
    //           tab2Method: tempArry,
    //           tab2MethodValue: tempArry[0].value
    //         })

    //         console.log("thismethod",_this.data.tab2Method)

    //       }

    //     });
    //   },


    //自动匹配政策
    pipei() {
        var _this = this;
        console.log("pipei", _this.data.tab2Policy)

        Toast({
            type: 'loading',
            message: '自动匹配政策计算中...请稍后……',
            duration: 2000,
            onClose: () => {
                Toast({
                    type: 'success',
                    message: '已根据数据和算法为您推荐政策和工具！',
                    duration: 3500,
                });

                // var i = Math.round(Math.random() * 2)
                // var j = Math.round(Math.random() * 2)
                // var k = Math.round(Math.random() * 2)
                var i=0
                var j=0
                var k=0

                console.log("i==", i, "j==", j, k)


                // _this.setData({

                // tab2PolicyValue:i,
                // });
                //获取对应的方法数组    
                // _this.getMethods()  
                if(this.data.tab2MethodValue4==0){
                    _this.setData({
                        tab2MethodValue: 3,
                        tab2MethodValue2: i,
                        tab2MethodValue3: k,
                        shudian1:"扩大国内大豆种植面积；提高大豆农业机械化水平及技术推广，提高土壤肥力。促进与贸易伙伴合作，多元化采购渠道。",
                        shudian2:"【二手车交易】：生态环境部和商务部联合发布《关于促进二手车便利交易的若干意见》。这项政策主要目的是进一步促进二手车便利交易，推动汽车消费。",
                        shudian3:"【新能源汽车】：国务院办公厅发布《关于加快新能源汽车推广应用的若干政策措施》。这项政策主要目的是加快新能源汽车的推广应用，推动新能源汽车的发展。",
                    });
                }
                else if(this.data.tab2MethodValue4==1){
                    _this.setData({
                        tab2MethodValue: 2,
                        tab2MethodValue2: 1,
                        tab2MethodValue3: 1,
                        shudian1:"【普惠金融类】: 由政府对芯片供应链行业进行补贴，扶持国内芯片企业，主要用于鼓励中国企业购买本土半导体设备，提供20%采购成本补贴。",
                        shudian2:"【税收优惠类】：税务部门对芯片供应链行业减免税之类的政策，有利于中小微企业经营",
                        shudian3:"【疏解政策类】：政府对供应链企业疏解库存，疏解供应链的存储等,减少库存压力并降低成本",
                    });
                }
                else if(this.data.tab2MethodValue4==1){
                    _this.setData({
                        tab2MethodValue: 1,
                        tab2MethodValue2: 2,
                        tab2MethodValue3: 3,
                        shudian1:"【普惠金融类】: 由政府对芯片供应链行业进行补贴，扶持国内芯片企业，主要用于鼓励中国企业购买本土半导体设备，提供20%采购成本补贴。",
                        shudian2:"【税收优惠类】：税务部门对芯片供应链行业减免税之类的政策，有利于中小微企业经营",
                        shudian3:"【疏解政策类】：政府对供应链企业疏解库存，疏解供应链的存储等,减少库存压力并降低成本",
                    });
                }
                


            }
        });

    },


    //多重政策
    many() {
        var _this = this;
        console.log("many", _this.data.tab2Policy)

        // Toast({
        //     type: 'loading',
        //     message: '多重政策分析中...请稍后……',
        //     duration: 2000,
        //     onClose: () => {
        wx.showModal({
            title: '施策分析政策匹配确认',
            
            content: '您选择的施策对象是,【' + _this.data.tab2CarryEntities[_this.data.tab2CarryEntitiesValue].text + '】，施策工具1是：【普惠金融类】,疏解方法是：【' + _this.data.tab2Method[_this.data.tab2MethodValue].text + '】,施策工具2是：【税收优惠类】,疏解方法是：【' + _this.data.tab2Method2[_this.data.tab2MethodValue2].text + '】,施策工具3是：【疏解政策类】,疏解方法是：【' + _this.data.tab2Method3[_this.data.tab2MethodValue3].text +
                '】。                        国办的政策直接影响到国务院日常工作，发改委政策会影响多个部门决策，央行施策会影响银行的决策，请仔细考虑',
            success(res) {
                if (res.confirm) {
                    Toast({
                        type: 'loading',
                        message: '多重政策分析中...请稍后……',
                        duration: 2000,
                        onClose: () => {

                            wx.showModal({
                                title: '施策的直接效果',
                                confirmText:'进入仿真',
                                confirmColor:'#576B95',
                                content: '【' + _this.data.tab2Method[_this.data.tab2MethodValue].text + '】使国务院对该事件给出了指导政策，从系统层面解决了一些堵点。【' + _this.data.tab2Method2[_this.data.tab2MethodValue2].text + '】提高了该事件在市场中【' + Math.round(Math.random() * 50) + '%】的效率，【' + _this.data.tab2Method3[_this.data.tab2MethodValue3].text + '】会导致【' + Math.round(Math.random() * 100) + '】家银行加大对该领域的投资。具体请点击进入仿真查看',
                                success (res) {
                                    if (res.confirm) {
                                      _this.jumpToTab3()
                                    } else if (res.cancel) {
                                      console.log('用户点击取消')
                                    }
                                  }
                            })

                        }
                    })





                } else if (res.cancel) {
                    console.log('用户点击取消')
                }
            }
        })

        //     }
        //   });

    },


    //施策分析
    analysis() {

        var _this = this;
        console.log("tab2policy", _this.data.tab2Policy)
        wx.showModal({
            title: '施策分析政策匹配确认',
            content: '您选择的施策对象是,【' + _this.data.tab2CarryEntities[_this.data.tab2CarryEntitiesValue].text + '】\r\n，施策工具1是：【普惠金融类】,疏解方法是：【' + _this.data.tab2Method[_this.data.tab2MethodValue].text + '】\r\n,施策工具2是：【税收优惠类】,疏解方法是：【' + _this.data.tab2Method2[_this.data.tab2MethodValue2].text + '】\r\n,施策工具3是：【疏解政策类】,疏解方法是：【' + _this.data.tab2Method3[_this.data.tab2MethodValue3].text + '】\r\n,该疏解工具和方法将对供应链相关节点造成影响，请确定是否继续？',
            success(res) {
                if (res.confirm) {
                    console.log('用户点击确定')
                    Toast({
                        type: 'loading',
                        message: '施策分析中...',
                        duration: 1500,
                        onClose: () => {

                            wx.showModal({
                                title: '施策分析结果',
                                confirmText:"进入仿真",
                                content: '该操作对主体节点和相关【【' + Math.round(Math.random() * 15) + '】】个节点造成影响,减少的系统风险值为：【【' + Math.round(Math.random() * 10) + '】】,点击查看相关节点。具体请点击进入仿真查看',
                                success(res) {
                                    if (res.confirm) {
                                        console.log('用户点击确定')
                                        _this.jumpToTab3()

                                    } else if (res.cancel) {
                                        console.log('用户点击取消')
                                    }
                                }
                            })

                        }
                    });


                } else if (res.cancel) {
                    console.log('用户点击取消')
                }
            }
        })

        _this.setData({
            carryEntityUserRemarks: []
        })
        // var carryEntityId = _this.data.tab2CarryEntitiesValue;

        // if (carryEntityId == 0) {
        //   _this.setData({
        //     customizeCarryEntityId: []
        //   })

        //   _this.getEntityIdByName(_this.data.customizeCarryEntity1);

        //   for (var i = 0; i < _this.data.customizeCarryEntity2InputVal.length; i++) {
        //     _this.getEntityIdByName(_this.data.customizeCarryEntity2InputVal[i]);
        //   }
        // } else {
        //   _this.getCarryEntityDetail(carryEntityId);
        //   _this.getCarryEffect(carryEntityId);
        //   setTimeout(function () {
        //     _this.getUserRemarks(app.globalData.openid, carryEntityId, 2);
        //   }, 2000);
        //   setTimeout(function () {
        //     Toast.clear();
        //     Toast.success('施策成功...');
        //   }, 2000);
        // }
        // _this.setData({
        //   downLoadAnalysisFileStatus: false
        // });

    },
    downLoadAnalysisFile() {
        var _this = this;
        _this.getShareFileUrl(_this.data.tab0Value1, _this.data.tab0Value2, _this.data.tab2CarryEntitiesValue, _this.data.tab2PolicyValue, _this.data.tab2MethodValue)

    },
    report(event) {
        var _this = this;
        wx.navigateTo({
            url: '../report/report?entityId=' + event.currentTarget.dataset.idx,
            events: {
                // 为指定事件添加一个监听器，获取被打开页面传送到当前页面的数据
                acceptDataFromOpenedPage: function (data) {

                    if (event.currentTarget.dataset.type == "1") {
                        var temp = _this.data.blockEntityUserRemarks;
                        temp.push(data.data)
                        _this.setData({
                            blockEntityUserRemarks: temp
                        })

                        console.log("blockEntityUserRemarks" + _this.data.blockEntityUserRemarks)
                    } else {
                        var temp = _this.data.carryEntityUserRemarks;

                        temp.push(data.data)
                        _this.setData({
                            carryEntityUserRemarks: temp
                        })

                    }
                }
            }
        })
    },
    getUserRemarks(openid, entityId, type) {
        console.log(type + " getUserRemarks开始执行。。。。")
        console.log(openid + '..' + entityId + '..' + type)
        var _this = this;

        wx.request({
            url: 'http://localhost:5000/api/risk/login/getUserRemarks/?openid=' + openid + '&entityId=' + entityId,
            header: {
                'content-type': 'application/json' // 默认值
            },
            success(res) {
                console.log(res)
                if (type == 1) {
                    _this.setData({
                        blockEntityUserRemarks: res.data.remarks
                    })
                    console.log(_this.data.blockEntityUserRemarks);
                } else {
                    _this.setData({
                        carryEntityUserRemarks: res.data.remarks
                    })
                    console.log(_this.data.carryEntityUserRemarks);
                }
            }
        });
    },
    getEntityIdByName(name) {
        var _this = this;
        wx.request({
            url: 'http://localhost:5000/api/risk/getEntityByName/?name=' + name,
            header: {
                'content-type': 'application/json' // 默认值
            },
            success(res) {
                if (res.data.entityId == -1 || _this.data.customizeCarryEntityId.indexOf(res.data.entityId) > -1) {
                    Toast.clear();
                    Toast.fail('输入有误...');
                    return;
                } else {
                    var temp = _this.data.customizeCarryEntityId;
                    temp.push(res.data.entityId);
                    _this.setData({
                        customizeCarryEntityId: temp
                    })
                    Toast.clear();
                    Toast.success('施策成功...');
                }
            }
        });
    },
    //获取对指定节点的施策效果
    getCarryEffect(entityId) {
        var _this = this;
        wx.request({
            url: 'http://localhost:5000/api/risk/getCarryEffect/?id=' + entityId + '&policy_id=' + 1 + '&method_id=' + 1,
            header: {
                'content-type': 'application/json' // 默认值
            },
            success(res) {

                _this.setData({
                    relatedCarryEntities: res.data.nodes,
                    effect_nums: res.data.effect_nums
                })
                var desc = [];
                console.log(_this.data.relatedCarryEntities.length);
                desc.push("本次施策共影响主体" + res.data.nodes.length + "个，预计疏通主体" + res.data.effect_nums + "个，疏解效果" + (res.data.nodes.length < res.data.effect_nums * 2 ? "良好" : "一般"));
                _this.setData({
                    desc: desc,
                    loads: false,
                    analysisResultActiveNames: ['1'],
                });
            }
        });
    },
    //生成分析报告
    getShareFileUrl(chainName, chainType, entityId, policyId, methodId) {
        var _this = this;
        var urlData = 'http://localhost:5000/api/risk/makeCarryFile/?chain_name=' + encodeURIComponent(chainName) + '&chain_type=' + encodeURIComponent(chainType) + '&entity_id=' + entityId + '&policy_id=' + 1 + '&method_id=' + 1;
        wx.setClipboardData({
            data: urlData + "，点击链接查看施策仿真分析报告【来自供应链安全评估与施策仿真】",
            success(res) {
                wx.getClipboardData({
                    success(sres) {
                        console.log(sres.data) // data
                    }
                })
            }
        })

    },
    //获取堵点详细信息
    getBlockEntityDetail(detail) {
        var _this = this;
        console.log("idd",detail)
        setTimeout(function () {
            // wx.request({
            //     url: 'http://localhost:5000/api/risk/getEntityData/?id=' + _this.data.blockEntities2Value,
            //     header: {
            //         'content-type': 'application/json' // 默认值
            //     },
            //     success(res) {
                   

            //         // if (res.data.comp[4] > 70) {
            //         //     res.data.comp[1] += "--【库存风险】"
            //         // }




            //         //堵点名字
            //         if(_this.data.blockEntities2Value==43)
            //         res.data.comp[1]="汽车制造需要大量原材料，如钢铁、塑料、橡胶等。原材料供应链中的短缺、价格波动或质量问题都可能对生产造成困扰"
            //         else if(_this.data.blockEntities2Value==36)
            //         res.data.comp[1]="汽车制造商依赖众多供应商提供零部件和组件。供应商的破产、生产问题、质量问题或交付延误都可能对汽车制造造成重大问题"
            //         else if(_this.data.blockEntities2Value==37)
            //         res.data.comp[1]="交付零部件和完成的汽车涉及到复杂的物流网络。运输延误、货物损坏或丢失、货运成本上升等问题都可能对供应链产生负面影响"
            //         else if(_this.data.blockEntities2Value==39)
            //         res.data.comp[1]="汽车行业受到严格的法规和政策监管。政府政策变化、贸易纷争和环保法规变更都可能对供应链产生影响。例如税收优惠到期引起汽车涨价,欧洲反倾销导致出口价格增加"
            //         else if(_this.data.blockEntities2Value==46)
            //         res.data.comp[1]="汽车市场对季节性和经济波动非常敏感。市场需求的急剧变化可能导致库存积压或生产不足。"

            //         _this.setData({
            //             blockEntity: res.data.comp,
            //         })
            //         console.log('成功获取堵点分析的信息', res.data.comp);
            //     }

            // });
            if(detail==0){
                _this.setData({
                    blockEntity: [0,"汽车制造需要大量原材料，如钢铁、塑料、橡胶等。原材料供应链中的短缺、价格波动或质量问题都可能对生产造成困扰",1,2,34,86],
                })
            }else if(detail==1){
                _this.setData({
                    blockEntity: [1,"汽车制造商依赖众多供应商提供零部件和组件。供应商的破产、生产问题、质量问题或交付延误都可能对汽车制造造成重大问题",1,2,58,46],
                })
            }else if(detail==2){
                _this.setData({
                    blockEntity: [2,"交付零部件和完成的汽车涉及到复杂的物流网络。运输延误、货物损坏或丢失、货运成本上升等问题都可能对供应链产生负面影响",1,2,75,32],
                })
            }else if(detail==3){
                _this.setData({
                    blockEntity: [3,"汽车行业受到严格的法规和政策监管。政府政策变化、贸易纷争和环保法规变更都可能对供应链产生影响。例如税收优惠到期引起汽车涨价,欧洲反倾销导致出口价格增加",1,2,43,38],
                })
            }else if(detail==4){
                _this.setData({
                    blockEntity: [4,"汽车市场对季节性和经济波动非常敏感。市场需求的急剧变化可能导致库存积压或生产不足",1,2,84,76],
                })
            }
            


        }, 200);
    },
    getCarryEntityDetail(id) {

        var _this = this;
        wx.request({
            url: 'http://localhost:5000/api/risk/getEntityData/?id=' + id,
            header: {
                'content-type': 'application/json' // 默认值
            },
            success(res) {
                console.log(res.data.comp)
                _this.setData({
                    carryEntity: res.data.comp,
                })
            }

        });
    },
    //获取堵点关联信息
    getBlockage() {
        console.log("获取堵点关联信息222")
        
        var _this = this;
        //这个没有成功
        // setTimeout(function () {
        //     wx.request({
        //         url: 'http://localhost:5000/api/risk/getBlockAge/?companyId=' + _this.data.blockEntities2Value,
        //         header: {
        //             'content-type': 'application/json' // 默认值
        //         },
        //         success(res) {
        //             console.log("成功获取到堵点关联信息", res.data.nodes)
        //             res.data.nodes.forEach((value, index) => {
        //                 if (value.name === '新冠疫情') {
        //                     res.data.nodes.splice(index, 1)
        //                 }
        //             })

        //             _this.setData({
        //                 relatedBlockEntities: res.data.nodes,
        //             })

        //             var desc = [];
        //             desc.push(_this.data.blockEntity[1] + "堵塞，预计共" + _this.data.relatedBlockEntities.length + "个主体会受到影响，造成影响" + (_this.data.relatedBlockEntities.length > 5 ? "严重" : "一般"));
        //             console.log("获取堵点关联信息333")
        //             _this.setData({
        //                 blockDesc: desc,
        //             });
        //             // const graph = res.data;
        //             // options.series[0].data = graph.nodes;
        //             // options.series[0].links = graph.links;
        //             // chart.setOption(options);
        //             // console.log("chart option设置成功。。")
        //         }
        //     });
        // }, 2100);

        var desc = [];


        
        _this.setData({
            relatedBlockEntities: [{'name':'钢铁制造公司：武汉钢铁','risk':'严重','relation':'直接相关'},
            {'name':' 钢铁生产公司：宝钢集团','risk':'严重','relation':'间接相关'},
            {'name':'塑料制造公司：华友化工','risk':'一般','relation':'间接相关'},
            {'name':'橡胶制造公司：普利制胶','risk':'一般','relation':'间接相关'},
            {'name':'金属供应商：江铜集团','risk':'轻微','relation':'间接相关'}
        ],
        })

        //根据选择的问题出现不同的公司
        if(_this.data.blockEntities2Value==43){
            desc.push("原材料供应问题堵塞，预计共5个主体节点受到影响，造成影响：严重");

        }
       
        else if(_this.data.blockEntities2Value==36){
            desc.push("库存问题堵塞，预计共5个主体节点受到影响，造成影响：严重");
            _this.setData({
                relatedBlockEntities: [{'name':'汽车制造商：上汽集团','risk':'严重','relation':'直接相关'},
                {'name':' 汽车制造商：长城汽车','risk':'严重','relation':'间接相关'},
                {'name':'零部件供应商：宁波联塑集团','risk':'一般','relation':'间接相关'},
                {'name':'零部件供应商:博世汽车部件','risk':'一般','relation':'间接相关'},
                {'name':'汽车制造商：吉利汽车','risk':'轻微','relation':'间接相关'}
                 ],
            })
        }


        
        else if(_this.data.blockEntities2Value==37){
            desc.push("物流问题堵塞，预计共4个主体节点受到影响，造成影响：严重");
            _this.setData({
                relatedBlockEntities: [{'name':'圆通汽车物流','risk':'严重','relation':'直接相关'},
                {'name':' 中远国际货运代理','risk':'严重','relation':'间接相关'},
                {'name':'UPS中国','risk':'一般','relation':'间接相关'},
                {'name':'韵达快递','risk':'一般','relation':'间接相关'},
                
                 ],
            })

        }
        
        else if(_this.data.blockEntities2Value==39){
            desc.push("商贸问题堵塞，预计共7个主体节点受到影响，造成影响：严重");
            _this.setData({
                relatedBlockEntities: [{'name':'吉利控股集团','risk':'严重','relation':'直接相关'},
                {'name':'上汽集团','risk':'严重','relation':'间接相关'},
                {'name':'中国一汽集团','risk':'一般','relation':'间接相关'},
                {'name':'宇通汽车','risk':'一般','relation':'间接相关'},
                {'name':'比亚迪汽车','risk':'轻微','relation':'间接相关'},
                {'name':'北汽集团','risk':'轻微','relation':'间接相关'},
                
                 ],
            })


        }

        else if(_this.data.blockEntities2Value==46){
            desc.push("消费问题堵塞，预计共5个主体节点受到影响，造成影响：严重");
            _this.setData({
                relatedBlockEntities: [{'name':'汽车制造商：上汽集团','risk':'严重','relation':'直接相关'},
                {'name':' 汽车制造商：长城汽车','risk':'严重','relation':'间接相关'},
                {'name':'比亚迪汽车','risk':'一般','relation':'间接相关'},
                {'name':'宇通汽车','risk':'一般','relation':'间接相关'},
                {'name':'汽车制造商：吉利汽车','risk':'轻微','relation':'间接相关'}
                 ],
            })
        }


        
        
        
   
        _this.setData({
            blockDesc: desc,
        });

        // _this.setData({
        //         relatedBlockEntities: [{'name':'汽车制造商：上汽','risk':'严重','relation':'直接相关'},
        //         {'name':' 电池制造商：宁德时代','risk':'严重','relation':'间接相关'},
        //         {'name':'零部件供应商：宜华健康','risk':'一般','relation':'间接相关'},
        //         {'name':'发动机制造商:潍柴动力','risk':'一般','relation':'间接相关'},
        //         {'name':'变速器制造商:比亚迪','risk':'一般','relation':'间接相关'}
        //     ],
        //  })



    },

    // tab1  获取对应供应链的堵点
    getBlockEntities() {
        var _this = this;
        var risk_name = _this.data.tab0Value1;
        var risk_type = _this.data.tab0Value2;
        console.log("here1", risk_name, risk_type)
        wx.request({
            url: 'http://localhost:5000/api/risk/getBlockEntities/?category=' + risk_name + '&risk_type=' + risk_type,
            header: {
                'content-type': 'application/json' // 默认值
            },
            success(res) {
                console.log("成功获取到堵点", res.data.entities)
                // for (var i = 0; i < res.data.entities.length; i++) {
                    // if (res.data.entities[i][2] < 70 && res.data.entities[i][2] > 60)
                    //     res.data.entities[i][1] = "---【库存风险】"
                    // else if (res.data.entities[i][2] > 70 && res.data.entities[i][2] < 80)
                    //     res.data.entities[i][1] += "---【物流风险】"
                    // else if (res.data.entities[i][2] > 80 && res.data.entities[i][2] < 90)
                    // res.data.entities[i][1] += "---【价格风险】"
                    // else res.data.entities[i][1] += "---【商贸风险】"
                    
                // }

                //如果选择芯片 出堵点结果 

                // if(_this.data.tab0Value1=='芯片'){
                //     console.log("芯片 dd")
                //     res.data.entities[0][1]='芯片断链问题'
                // res.data.entities[1][1]='芯片库存问题'
                // res.data.entities[2][1]='芯片供应链价格问题'

                // }else if(_this.data.tab0Value1=='汽车'){
                //     console.log("汽车dd")
                //     res.data.entities[0][1]='订单过多问题'
                // res.data.entities[1][1]='车轮供应不足'
                // res.data.entities[2][1]='轮胎供应不足'
                // res.data.entities[3][1]='钢材供应不足'
                // res.data.entities[4][1]='橡胶供应不足'

                // }
                res.data.entities[0][1]='供应-原材料供应风险'
                res.data.entities[1][1]='库存-各级供应商风险'
                res.data.entities[2][1]='物流-货运和物流风险'
                res.data.entities[3][1]='商贸-法规和政策风险'
                res.data.entities[4]=[39,'消费-市场需求波动风险',33]

                // res.data.entities[4][1]='橡胶供应不足'
                // res.data.entities[0][1]='芯片断链问题'
                // res.data.entities[1][1]='芯片库存问题'
                // res.data.entities[2][1]='芯片供应链价格问题'
                // res.data.entities[3][1]='芯片供应链物流问题'


                _this.setData({
                    blockEntities: res.data.entities,
                })
            }

        })





        _this.setData({
            blockEntities: [ [39,' 供应-原材料供应风险',43],
            [39,'库存-各级供应商问题',61],
            [39,'物流-货运和物流风险',75],
            [39,'商贸-法规和政策风险',58],
            [39,'消费-市场需求波动风险',33]],
        })





    },
    // tab2 获取对应供应链的所有堵点
    getAllBlockEntities() {
        console.log("获取tab2所有堵点.......")
        var _this = this;
        var risk_name = _this.data.tab0Value1;
        var risk_type = "";
        console.log("here", risk_name, risk_type)
        wx.request({
            url: 'http://localhost:5000/api/risk/getBlockEntities/?category=' + risk_name + '&risk_type=' + risk_type,
            header: {
                'content-type': 'application/json' // 默认值
            },
            success(res) {
                var tempArry = [];
                for (var i = 0; i < res.data.entities.length; i++) {
                    var tempIndex = {
                        text: '1',
                        value: 1
                    }
                    var te = res.data.entities[i][1];
                    var val = res.data.entities[i][0];
                    tempIndex.text = te;
                    tempIndex.value = val;
                    tempArry.push(tempIndex);
                }
                console.log("成功获取到所有堵点", tempArry)

                
                    
                tempArry[0].text="供应-原材料供应风险"
                tempArry[1].text="库存-各级供应商问题"
                tempArry[2].text="物流-货运和物流风险"
                tempArry[3].text="商贸-法规和政策风险"
                tempArry[4].text="消费-市场需求波动风险"
                    

                


                _this.setData({
                    blockEntities2: tempArry,
                    blockEntities2Value: tempArry[0].value //序号
                })
                setTimeout(function () {
                    _this.getUserRemarks(app.globalData.openid, _this.data.blockEntities2Value, 1);
                }, 1000);
            }

            
        })


        
        


        _this.setData({
            blockEntities2: [{'text':"供应-原材料供应风险",'value':0},
            {'text':"库存-各级供应商问题",'value':1},
            {'text':"物流-货运和物流风险",'value':2},
            {'text':"商贸-法规和政策风险",'value':3},
            {'text':"消费-市场需求波动风险",'value':4}],
            blockEntities2Value: 0
        })
        setTimeout(function () {
            _this.getUserRemarks(app.globalData.openid, _this.data.blockEntities2Value, 1);
        }, 1000);

    },


    //获取对应供应链的疏点
    getCarryEntities() {
        var _this = this;
        var risk_name = _this.data.tab0Value1;
        var risk_type = _this.data.tab0Value2;
        wx.request({
            url: 'http://localhost:5000/api/risk/getCarryEntities/?category=' + risk_name + '&risk_type=' + risk_type,
            header: {
                'content-type': 'application/json' // 默认值
            },
            success(res) {
               
                console.log('疏点', res.data.entities)
                res.data.entities[0][1]="供应-多元化供应源"
                res.data.entities[1][1]="库存-供应商监管与多样性"
                res.data.entities[2][1]="物流-基础设施投资"
                res.data.entities[3]=[23,"商贸-保持政策稳定性与合规性",33]
                res.data.entities[4]=[22,"消费-市场监测和信息共享",11]
                _this.setData({
                    carryEntities: res.data.entities,
                });
            }
        })
        _this.setData({
            carryEntities: [[22,"供应-多元化供应源",67],
            [22,"库存-供应商监管与多样性",76],
            [22,"物流-基础设施投资",83],
            [23,"商贸-保持政策稳定性与合规性",33],
            [22,"消费-市场监测和信息共享",11]],
        });
    },
    //获取供应链所有建议疏点
    getAllCarryEntities() {
        var _this = this;
        var risk_name = _this.data.tab0Value1;
        var risk_type = "";
        wx.request({
            url: 'http://localhost:5000/api/risk/getCarryEntities/?category=' + risk_name + '&risk_type=' + risk_type,
            header: {
                'content-type': 'application/json' // 默认值
            },
            success(res) {
                var tempArry = [];
                // for (var i = 0; i < res.data.entities.length; i++) {
                //   var tempIndex = {
                //     text: '1',
                //     value: 1
                //   }
                //   var te = res.data.entities[i][1];
                //   var val = res.data.entities[i][0];
                //   tempIndex.text = te;
                //   tempIndex.value = val;
                //   tempArry.push(tempIndex);
                // }
                tempArry.push({
                    text: "汽车供应链",
                    value: 0
                });
                tempArry.push({
                    text: "雪松暴雷事件",
                    value: 1
                });
                tempArry.push({
                    text: "芯片供应链事件",
                    value: 2
                });
                tempArry.push({
                    text: "其他",
                    value: 3
                });
                _this.setData({
                    tab2CarryEntities: tempArry,
                    tab2CarryEntitiesValue: tempArry[0].value,
                })
            }
        })
    },
    navigateToMiniProgram(event) {
        // console.log(event.currentTarget.dataset.idx)
        wx.navigateToMiniProgram({
            appId: 'wx5a7e18cbda07907e',
            path: 'pages/graph/graph?flag=2&graph=' + event.currentTarget.dataset.idx,
            extraData: {
                from: '供应链安全管理'
            },
            envVersion: 'release',
            success(res) {
                // 打开其他小程序成功同步触发
                wx.showToast({
                    title: '跳转成功'
                })
            }
        })
    },
    tab2CarryEntitiesBind({
        detail
    }) {
        console.log("tab2bindentiti", detail)
        var _this = this;
        _this.setData({
            tab2CarryEntitiesValue: detail,

        });
        if (detail == 0) {
            //   _this.setData({
            //     reply: true,
            //   });
        } else {
            _this.setData({
                reply: false,
                customizeCarryEntity2Array: [], //默认显示一个
                customizeCarryEntity2InputVal: [] //所有input的内容
            })
        }
    },
    customizeCarryEntity(event) {
        var _this = this;

        _this.setData({
            customizeCarryEntity1: event.detail,
        })
    },
    //获取input的值
    getInputVal: function (e) {

        var nowIdx = e.currentTarget.dataset.idx; //获取当前索引
        var val = e.detail; //获取输入的值
        var oldVal = this.data.customizeCarryEntity2InputVal;
        oldVal[nowIdx] = val; //修改对应索引值的内容
        this.setData({
            customizeCarryEntity2InputVal: oldVal
        });

    },
    //添加input
    addInput: function () {
        var old = this.data.customizeCarryEntity2Array;
        old.push(1); //这里不管push什么，只要数组长度增加1就行
        this.setData({
            customizeCarryEntity2Array: old
        })
    },
    //删除input
    delInput: function (e) {
        var nowidx = e.currentTarget.dataset.idx; //当前索引
        var oldInputVal = this.data.customizeCarryEntity2InputVal; //所有的input值
        var oldarr = this.data.customizeCarryEntity2Array; //循环内容
        oldarr.splice(nowidx, 1); //删除当前索引的内容，这样就能删除view了
        oldInputVal.splice(nowidx, 1); //view删除了对应的input值也要删掉

        this.setData({
            customizeCarryEntity2Array: oldarr,
            customizeCarryEntity2InputVal: oldInputVal
        })
    },
    //   tab2PolicyBind({
    //     detail
    //   }) {
    //     var _this = this;

    //     _this.setData({
    //       tab2PolicyValue: detail,
    //     });
    //     if (detail == 0) {
    //     //   _this.setData({
    //     //     policyReply: true,
    //     //   });
    //     } else {
    //       _this.getMethods();
    //       _this.setData({
    //         policyReply: false,
    //         customizePolicy2Array: [], //默认显示0个
    //         customizePolicy2InputVal: [], //所有input的内容
    //       })
    //     }

    //   },
    customizePolicy(event) {
        var _this = this;

        _this.setData({
            customizePolicy1: event.detail,
        })
    },
    //获取input的值
    getPolicyInputVal: function (e) {

        var nowIdx = e.currentTarget.dataset.idx; //获取当前索引
        var val = e.detail; //获取输入的值

        console.log("policy", e.detail)

        var oldVal = this.data.customizePolicy2InputVal;
        oldVal[nowIdx] = val; //修改对应索引值的内容
        this.setData({
            customizePolicy2InputVal: oldVal
        });

    },
    //添加input
    addPolicyInput: function () {
        var old = this.data.customizePolicy2Array;
        old.push(1); //这里不管push什么，只要数组长度增加1就行
        console.log('old', old)
        this.setData({
            customizePolicy2Array: old
        })
    },
    //删除input
    delPolicyInput: function (e) {
        var nowidx = e.currentTarget.dataset.idx; //当前索引
        var oldInputVal = this.data.customizePolicy2InputVal; //所有的input值
        var oldarr = this.data.customizePolicy2Array; //循环内容
        oldarr.splice(nowidx, 1); //删除当前索引的内容，这样就能删除view了
        oldInputVal.splice(nowidx, 1); //view删除了对应的input值也要删掉

        this.setData({
            customizePolicy2Array: oldarr,
            customizePolicy2InputVal: oldInputVal
        })
    },

    tab2MethodBind({
        detail
    }) {

        this.setData({
            tab2MethodValue: detail,
        });
        // if (detail == 0) {
        // //   this.setData({
        // //     methodReply: true,
        // //   });
        // } else {
        //   this.setData({
        //     methodReply: false,
        //     customizeMethod2Array: [], //默认显示0个
        //     customizeMethod2InputVal: [], //所有input的内容
        //   })
        // }
    },

    tab2MethodBind2({
        detail
    }) {

        this.setData({
            tab2MethodValue2: detail,
        });
    },

    tab2MethodBind3({
        detail
    }) {

        this.setData({
            tab2MethodValue3: detail,
        });
    },

    tab2MethodBind4({
        detail
    }) {
        console.log("dianji",detail)

        wx.showLoading({
            title: '请稍候...',
            mask: true // 显示透明蒙层，防止触摸穿透
          });
      
          // 设置定时器，假设我们需要等待3秒
          setTimeout(() => {
            // 隐藏加载提示框
            wx.hideLoading();
      
            // 这里执行你的任务
            if(detail==0){
                this.setData({
                    tab2MethodValue4: detail,
                    fengxianleixing:"库存累积风险型",
                    zhengce1:"国家购置税减免政策，对新能源汽车减免征收车辆购置税",
                    zhengce2:"优化供应链管理政策,政府提供财政补贴或税收减免",
                    zhengce3:"建立专门的供应链金融支持机制，帮助中小企业解决资金周转问题",
                    zhengce4:"鼓励汽车制造商和供应商多元化其原材料和零部件来源",

                    reason1:" 该政策旨在促进新能源汽车的销售和普及。通过减免车辆购置税，降低了消费者购买新能源汽车的成本，从而刺激需求。",
                    reason2:" 旨在降低企业运营成本，提高供应链效率。政府的财政补贴或税收减免可以缓解企业的财务压力，特别是在遇到供应链中断或原材料价格上涨时。",
                    reason3:"专注于解决中小企业在供应链中面临的资金获取难题。通过提供专门的金融服务，如短期贷款或信贷担保，帮助企业缓解资金周转困难。",
                    reason4:"通过多元化供应链来减少对单一供应商或地区的依赖，降低供应中断的风险。这有助于提高整个供应链的稳定性和抵抗外部冲击的能力。",



                    
                });
            
                
            }else if(detail==1){
                this.setData({
                    tab2MethodValue4: detail,
                    fengxianleixing:"上游企业过多风险",
                    zhengce1:"国家发展和改革委员会：促进产业整合与重组,可以鼓励行业内的并购重组",
                    zhengce2:"商务部：提高行业准入门槛,对新进入者设置更高的准入门槛",
                    zhengce3:"科技部：促进技术创新和升级,推广先进制造技术和管理方法",
                    zhengce4:"工业和信息化部：建立健全供应链风险监控机制,鼓励企业之间建立信息共享机制",

                    reason1:" 此政策旨在通过促进产业整合和重组，提高产业集中度和效率，淘汰落后产能。鼓励并购重组可以帮助形成更有竞争力的大型企业集团，提升行业整体实力。",
                    reason2:" 该政策目的是通过提高准入门槛，确保新进入市场的企业具有一定的实力和水平，从而提升整个行业的质量和竞争力",
                    reason3:"通过推动技术创新和应用先进的制造技术与管理方法，提高产品质量和生产效率，增强企业的核心竞争力和行业的技术水平。",
                    reason4:"此政策意在通过建立供应链风险监控和信息共享机制，增强企业对供应链风险的预警和应对能力，提高供应链的整体稳定性和抗风险能力。",
                });
    
            }
            else if(detail==2){
                this.setData({
                    tab2MethodValue4: detail,
                    fengxianleixing:"物流运输风险",
                    zhengce1:"交通运输部：制定物流运输安全标准、优化运输网络布局",
                    zhengce2:"国家发展和改革委员会：定促进物流行业发展的经济政策、提高物流效率和降低成本的措施",
                    zhengce3:"商务部：降低物流运输成本，提升供应链管理和服务水平",
                    zhengce4:"公安部：加强道路交通安全管理，制定物流运输车辆管理规定",

                    reason1:" 此政策旨在通过制定严格的运输安全标准，确保物流运输的安全性，同时优化运输网络布局，提升运输效率。这可以减少物流事故，降低因运输延误或损坏造成的成本",
                    reason2:" 通过经济政策激励，如税收减免、财政补贴等，鼓励物流行业提升效率和降低运营成本。这有助于减轻企业负担，提高整体物流行业的服务质量和竞争力。",
                    reason3:"通过降低物流成本和提升供应链管理水平，企业可以提高市场竞争力，增加消费者满意度。此政策旨在通过优化流程、提高透明度和服务质量，实现这一目标",
                    reason4:"通过加强对物流运输车辆的管理，确保道路交通安全，减少事故发生。这包括对司机资格、车辆安全标准以及运输规则的严格要求",
                });
    
            }
            console.log('延时任务执行了');
      

          }, 6000);


        

        // this.setData({
        //     g_hiddenn: false,
        // })

        

        
    },

    customizeMethod(event) {
        var _this = this;

        _this.setData({
            customizeMethod1: event.detail,
        })
    },
    //获取input的值
    getMethodInputVal: function (e) {

        var nowIdx = e.currentTarget.dataset.idx; //获取当前索引
        var val = e.detail; //获取输入的值
        var oldVal = this.data.customizeMethod2InputVal;
        oldVal[nowIdx] = val; //修改对应索引值的内容
        this.setData({
            customizeMethod2InputVal: oldVal
        });

    },
    //添加input
    addMethodInput: function () {
        var old = this.data.customizeMethod2Array;
        old.push(1); //这里不管push什么，只要数组长度增加1就行
        this.setData({
            customizeMethod2Array: old
        })
    },
    //删除input
    delMethodInput: function (e) {
        var nowidx = e.currentTarget.dataset.idx; //当前索引
        var oldInputVal = this.data.customizeMethod2InputVal; //所有的input值
        var oldarr = this.data.customizeMethod2Array; //循环内容
        oldarr.splice(nowidx, 1); //删除当前索引的内容，这样就能删除view了
        oldInputVal.splice(nowidx, 1); //view删除了对应的input值也要删掉

        this.setData({
            customizeMethod2Array: oldarr,
            customizeMethod2InputVal: oldInputVal
        })
    },
    showSubItem() {
        this.setData({
            subItemVisible: true,
        });
    },
    onSubItemClose() {
        this.setData({
            subItemVisible: false,
        });
    },
    onItemPickerChange(event) {
        const {
            picker,
            value,
            index
        } = event.detail;
        if (index == 0) {
            picker.setColumnValues(1, citys[value[0]]);
            picker.setColumnIndex(1, 0);
        }
    },
    // 供应链选择
    onItemConfirm(event) {
        var _this = this;
        const {
            picker,
            value,
            index
        } = event.detail;
        console.log(event)

        _this.setData({
            chosenSupplyItem: value[0],
            subItemVisible: false
        })
    },

    // 弹出展示公式、计算方法和历史数据的弹出框
    showFormula(e) {
        var _this = this;
        console.log(e)
        // if(e.target.id === '供应安全指数') {
        _this.setData({
            formulaPopupVisible: true,
            chosenIndexTitle: e.target.id
        })
        // }
    },
    closeFormula() {
        this.setData({
            formulaPopupVisible: false
        })
    },
    getCalBasic() {
        var _this = this;
        var risk_name = _this.data.tab0Value1;
        wx.request({
            url: 'http://localhost:5000/api/risk/HistoryInfo',
            data: {
                type: risk_name
            },
            header: {
                'contenty-type': 'application/json'
            },
            success(res) {
                console.log('new controlelr', res)
                _this.setData({
                    supplyQuantity: res.data.supplyQuantity,
                    consumeQuantity: res.data.consumeQuantity,
                    supplyVisible: res.data.supplyQuantity.length > 0,
                    consumeVisible: res.data.consumeQuantity.length > 0,
                    stockQuantity: res.data.stockQuantity,
                    priceQuantity: res.data.priceQuantity
                })
            }
        })
    },
    onChangeCollapse(event) {
        var _this = this
        _this.setData({
            activeCollapse: event.detail
        })
    },
    onChangeYear(e) {
        year = e.detail;
        console.log(year);
        if (year != 0) {
            this.selectComponent('#monthCheck').set({
                disabled: false,
            })
        };
    },
    getRecords() {
        var _this = this;
        wx.request({
            url: 'http://localhost:5000/api/risk/makeMonthlyData/?year=' + year + '&month=' + month,
            header: {
                'contenty-type': 'application/json'
            },
            success(res) {
                console.log('data', res);
                _this.setData({
                    riskReport: res.data.records
                })
            }
        })
    },
    onChangeMonth(e) {
        month = e.detail;
        console.log(month);
        if (month != 0) {
            wx.showToast({
                title: '载入数据中',
                icon: 'loading',
                duration: 500
            })
            this.getRecords();
        }
    },
    downLoadAnalysisReport() {
        if (year == 0 || month == 0) {
            wx.showToast({
                icon: "none",
                title: '请选择具体年月',
                duration: 2000
            })
        } else {
            var urlData = 'http://localhost:5000/api/risk/makeMonthlyFile/?year=' + year + '&month=' + month;
            wx.setClipboardData({
                data: urlData + "，点击链接查看月度风险预警报告【来自供应链安全评估与施策仿真】",
                success(res) {
                    wx.getClipboardData({
                        success(sres) {
                            wx.showToast({
                                icon: "warn",
                                title: '报告链接已复制',
                                duration: 2000
                            })
                            console.log(sres.data) // data
                        }
                    })
                }
            })


        }
    }
});