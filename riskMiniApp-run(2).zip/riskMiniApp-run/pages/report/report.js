// pages/report/report.js
import Toast from '@vant/weapp/toast/toast';
Page({

  /**
   * 页面的初始数据
   */
  data: {
    entityId: -1,
    title: '',
    message: '',
    email: '',
    from: '',
    eventChannel:''
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    this.setData({
      eventChannel: this.getOpenerEventChannel()
    })
    
    this.setData({
      entityId: options.entityId
    });
    console.log(options);
  },

  onTitleChange(event) {
    var _this = this;
    _this.setData({
      title: event.detail
    });
  },
  onMessageChange(event) {
    var _this = this;
    _this.setData({
      message: event.detail
    });
  },
  onEmailChange(event) {
    var _this = this;
    _this.setData({
      email: event.detail
    });
  },
  onFromChange(event) {
    var _this = this;
    _this.setData({
      from: event.detail
    });
  },
  submit: function () {
    var _this = this;
    if (_this.data.title == '' || _this.data.message == '' || _this.data.from == '' || _this.data.email == '') {
      Toast.fail('请检查输入是否为空...');
    } else {
      var app = getApp();
      var openid = app.globalData.openid;
      _this.data.eventChannel.emit('acceptDataFromOpenedPage', {data:[_this.data.title, _this.data.message]});
      wx.request({
        url: 'http://localhost:5000/api/risk/postRemarks/?openid=' + openid + '&entityId=' + _this.data.entityId + '&title=' + _this.data.title + '&message=' + _this.data.message + '&from=' + _this.data.from + '&email=' + _this.data.email,
        header: {
          'content-type': 'application/json' // 默认值
        },
        method: "POST",
        success(res) {
          Toast({
            type: 'success',
            message: '备注成功',
            onClose: () => {
              wx.navigateBack({
                delta: 1,
              })
            }
          });
          }
      })
      

    }
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})